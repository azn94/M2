package fr.su.generator;

import com.google.common.base.Objects;
import com.google.common.collect.Iterables;
import fr.su.stateMachineDsl.Input;
import fr.su.stateMachineDsl.LabelName;
import fr.su.stateMachineDsl.ListOfLabels;
import fr.su.stateMachineDsl.SingleLabel;
import fr.su.stateMachineDsl.State;
import fr.su.stateMachineDsl.StateMachine;
import fr.su.stateMachineDsl.StateMachineDeclaration;
import fr.su.stateMachineDsl.Transition;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.xtend2.lib.StringConcatenation;
import org.eclipse.xtext.generator.AbstractGenerator;
import org.eclipse.xtext.generator.IFileSystemAccess2;
import org.eclipse.xtext.generator.IGeneratorContext;
import org.eclipse.xtext.xbase.lib.Conversions;
import org.eclipse.xtext.xbase.lib.Functions.Function1;
import org.eclipse.xtext.xbase.lib.IterableExtensions;
import org.eclipse.xtext.xbase.lib.IteratorExtensions;

/**
 * Generates code from your model files on save.
 * 
 * See https://www.eclipse.org/Xtext/documentation/303_runtime_concepts.html#code-generation
 */
@SuppressWarnings("all")
public class StateMachineDslGenerator extends AbstractGenerator {
  public CharSequence generatePUML(final String contents) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("@startuml");
    _builder.newLine();
    _builder.append(contents);
    _builder.newLineIfNotEmpty();
    _builder.append("@enduml");
    return _builder;
  }
  
  @Override
  public void doGenerate(final Resource resource, final IFileSystemAccess2 fsa, final IGeneratorContext context) {
    String rtr = "";
    Iterable<StateMachine> machine = Iterables.<StateMachine>filter(IteratorExtensions.<EObject>toIterable(resource.getAllContents()), StateMachine.class);
    final Iterable<StateMachine> _converted_machine = (Iterable<StateMachine>)machine;
    Iterable<StateMachineDeclaration> decl = Iterables.<StateMachineDeclaration>filter((((StateMachine[])Conversions.unwrapArray(_converted_machine, StateMachine.class))[0]).getElements(), StateMachineDeclaration.class);
    final Iterable<StateMachineDeclaration> _converted_decl = (Iterable<StateMachineDeclaration>)decl;
    Iterable<Input> inputs = Iterables.<Input>filter((((StateMachineDeclaration[])Conversions.unwrapArray(_converted_decl, StateMachineDeclaration.class))[0]).getElements(), Input.class);
    int _size = IterableExtensions.size(inputs);
    boolean _equals = (_size == 0);
    if (_equals) {
      String _rtr = rtr;
      rtr = (_rtr + "There is no word to analyze yet. Try to input some words in the machine.");
    } else {
      final Iterable<StateMachineDeclaration> _converted_decl_1 = (Iterable<StateMachineDeclaration>)decl;
      final Function1<State, Boolean> _function = (State s) -> {
        return Boolean.valueOf(s.isIsInitial());
      };
      final Iterable<State> initials = IterableExtensions.<State>filter(Iterables.<State>filter((((StateMachineDeclaration[])Conversions.unwrapArray(_converted_decl_1, StateMachineDeclaration.class))[0]).getElements(), State.class), _function);
      final Iterable<StateMachineDeclaration> _converted_decl_2 = (Iterable<StateMachineDeclaration>)decl;
      final Function1<State, Boolean> _function_1 = (State s) -> {
        return Boolean.valueOf(s.isIsFinal());
      };
      final Iterable<State> finals = IterableExtensions.<State>filter(Iterables.<State>filter((((StateMachineDeclaration[])Conversions.unwrapArray(_converted_decl_2, StateMachineDeclaration.class))[0]).getElements(), State.class), _function_1);
      for (final State i : initials) {
        String _rtr_1 = rtr;
        String _format = String.format("[*] --> %s\n", i.getName());
        rtr = (_rtr_1 + _format);
      }
      for (final State f : finals) {
        String _rtr_2 = rtr;
        String _format_1 = String.format("%s --> [*] \n", f.getName());
        rtr = (_rtr_2 + _format_1);
      }
      final Iterable<StateMachineDeclaration> _converted_decl_3 = (Iterable<StateMachineDeclaration>)decl;
      final Iterable<Transition> transitions = Iterables.<Transition>filter((((StateMachineDeclaration[])Conversions.unwrapArray(_converted_decl_3, StateMachineDeclaration.class))[0]).getElements(), Transition.class);
      for (final Transition t : transitions) {
        {
          String _rtr_3 = rtr;
          String _name = t.getSource().getName();
          String _plus = (_name + "--> ");
          String _name_1 = t.getTarget().getName();
          String _plus_1 = (_plus + _name_1);
          rtr = (_rtr_3 + _plus_1);
          String _name_2 = t.getType().getName();
          boolean _notEquals = (!Objects.equal(_name_2, ""));
          if (_notEquals) {
            String _rtr_4 = rtr;
            String _format_2 = String.format(": %s", t.getType().getName());
            rtr = (_rtr_4 + _format_2);
          }
          String _rtr_5 = rtr;
          rtr = (_rtr_5 + " \n");
        }
      }
      final Iterable<StateMachineDeclaration> _converted_decl_4 = (Iterable<StateMachineDeclaration>)decl;
      final List<SingleLabel> singleLabels = IterableExtensions.<SingleLabel>toList(Iterables.<SingleLabel>filter((((StateMachineDeclaration[])Conversions.unwrapArray(_converted_decl_4, StateMachineDeclaration.class))[0]).getElements(), SingleLabel.class));
      final Iterable<StateMachineDeclaration> _converted_decl_5 = (Iterable<StateMachineDeclaration>)decl;
      final List<ListOfLabels> listLabels = IterableExtensions.<ListOfLabels>toList(Iterables.<ListOfLabels>filter((((StateMachineDeclaration[])Conversions.unwrapArray(_converted_decl_5, StateMachineDeclaration.class))[0]).getElements(), ListOfLabels.class));
      final List<LabelName> labels = new ArrayList<LabelName>();
      final Consumer<SingleLabel> _function_2 = (SingleLabel sl) -> {
        labels.add(sl.getLabel());
      };
      singleLabels.forEach(_function_2);
      final Consumer<ListOfLabels> _function_3 = (ListOfLabels ll) -> {
        labels.addAll(ll.getLabels());
      };
      listLabels.forEach(_function_3);
      for (final Input i_1 : inputs) {
        for (final State initial : initials) {
          {
            State current = initial;
            char[] inVal = i_1.getValue().toCharArray();
            int cpt = (-1);
            for (final char c : inVal) {
              {
                final Function1<LabelName, Boolean> _function_4 = (LabelName l) -> {
                  return Boolean.valueOf(l.getName().equals(String.valueOf(c)));
                };
                final Iterable<LabelName> match = IterableExtensions.<LabelName>filter(labels, _function_4);
                int _size_1 = IterableExtensions.size(match);
                boolean _equals_1 = (_size_1 == 0);
                if (_equals_1) {
                } else {
                  final State curseur = current;
                  final Function1<Transition, Boolean> _function_5 = (Transition t_1) -> {
                    return Boolean.valueOf((Objects.equal(t_1.getType(), ((Object[])Conversions.unwrapArray(match, Object.class))[0]) && (t_1.getSource() == curseur)));
                  };
                  final Iterable<Transition> tr = IterableExtensions.<Transition>filter(transitions, _function_5);
                  int _size_2 = IterableExtensions.size(tr);
                  boolean _equals_2 = (_size_2 == 0);
                  if (_equals_2) {
                  } else {
                    int _size_3 = IterableExtensions.size(tr);
                    boolean _greaterThan = (_size_3 > 1);
                    if (_greaterThan) {
                    } else {
                      int _size_4 = IterableExtensions.size(tr);
                      boolean _equals_3 = (_size_4 == 1);
                      if (_equals_3) {
                        current = (((Transition[])Conversions.unwrapArray(tr, Transition.class))[0]).getTarget();
                        int _cpt = cpt;
                        cpt = (_cpt + 1);
                      }
                    }
                  }
                  if (((cpt == (inVal.length - 1)) && current.isIsFinal())) {
                    String _rtr_3 = rtr;
                    String _format_2 = String.format("note Left of %s : this automaton does accept the word %s \n", current.getName(), i_1.getValue());
                    rtr = (_rtr_3 + _format_2);
                  }
                }
              }
            }
          }
        }
      }
    }
    Iterable<StateMachine> _filter = Iterables.<StateMachine>filter(IteratorExtensions.<EObject>toIterable(resource.getAllContents()), StateMachine.class);
    for (final StateMachine e : _filter) {
      String _name = (((StateMachineDeclaration[])Conversions.unwrapArray((Iterables.<StateMachineDeclaration>filter(e.getElements(), StateMachineDeclaration.class)), StateMachineDeclaration.class))[0]).getName();
      String _plus = (_name + ".puml");
      fsa.generateFile(_plus, 
        this.generatePUML(rtr));
    }
  }
}
