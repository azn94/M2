package fr.su.parser.antlr.internal;

import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtext.parser.antlr.AbstractInternalAntlrParser;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.parser.antlr.AntlrDatatypeRuleToken;
import fr.su.services.StateMachineDslGrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings("all")
public class InternalStateMachineDslParser extends AbstractInternalAntlrParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_ID", "RULE_INT", "RULE_STRING", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "RULE_WS", "RULE_ANY_OTHER", "'word'", "'automaton'", "'{'", "'}'", "'.'", "'import'", "'.*'", "'label'", "'labels'", "'state'", "'final'", "'initial'", "'transition'", "'event'", "'from'", "'to'"
    };
    public static final int RULE_STRING=6;
    public static final int RULE_SL_COMMENT=8;
    public static final int T__19=19;
    public static final int T__15=15;
    public static final int T__16=16;
    public static final int T__17=17;
    public static final int T__18=18;
    public static final int T__11=11;
    public static final int T__12=12;
    public static final int T__13=13;
    public static final int T__14=14;
    public static final int EOF=-1;
    public static final int RULE_ID=4;
    public static final int RULE_WS=9;
    public static final int RULE_ANY_OTHER=10;
    public static final int T__26=26;
    public static final int RULE_INT=5;
    public static final int T__22=22;
    public static final int RULE_ML_COMMENT=7;
    public static final int T__23=23;
    public static final int T__24=24;
    public static final int T__25=25;
    public static final int T__20=20;
    public static final int T__21=21;

    // delegates
    // delegators


        public InternalStateMachineDslParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public InternalStateMachineDslParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return InternalStateMachineDslParser.tokenNames; }
    public String getGrammarFileName() { return "InternalStateMachineDsl.g"; }



     	private StateMachineDslGrammarAccess grammarAccess;

        public InternalStateMachineDslParser(TokenStream input, StateMachineDslGrammarAccess grammarAccess) {
            this(input);
            this.grammarAccess = grammarAccess;
            registerRules(grammarAccess.getGrammar());
        }

        @Override
        protected String getFirstRuleName() {
        	return "StateMachine";
       	}

       	@Override
       	protected StateMachineDslGrammarAccess getGrammarAccess() {
       		return grammarAccess;
       	}




    // $ANTLR start "entryRuleStateMachine"
    // InternalStateMachineDsl.g:64:1: entryRuleStateMachine returns [EObject current=null] : iv_ruleStateMachine= ruleStateMachine EOF ;
    public final EObject entryRuleStateMachine() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleStateMachine = null;


        try {
            // InternalStateMachineDsl.g:64:53: (iv_ruleStateMachine= ruleStateMachine EOF )
            // InternalStateMachineDsl.g:65:2: iv_ruleStateMachine= ruleStateMachine EOF
            {
             newCompositeNode(grammarAccess.getStateMachineRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleStateMachine=ruleStateMachine();

            state._fsp--;

             current =iv_ruleStateMachine; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleStateMachine"


    // $ANTLR start "ruleStateMachine"
    // InternalStateMachineDsl.g:71:1: ruleStateMachine returns [EObject current=null] : ( (lv_elements_0_0= ruleAbstractElement ) )* ;
    public final EObject ruleStateMachine() throws RecognitionException {
        EObject current = null;

        EObject lv_elements_0_0 = null;



        	enterRule();

        try {
            // InternalStateMachineDsl.g:77:2: ( ( (lv_elements_0_0= ruleAbstractElement ) )* )
            // InternalStateMachineDsl.g:78:2: ( (lv_elements_0_0= ruleAbstractElement ) )*
            {
            // InternalStateMachineDsl.g:78:2: ( (lv_elements_0_0= ruleAbstractElement ) )*
            loop1:
            do {
                int alt1=2;
                int LA1_0 = input.LA(1);

                if ( ((LA1_0>=11 && LA1_0<=12)||LA1_0==16||(LA1_0>=18 && LA1_0<=20)||LA1_0==23) ) {
                    alt1=1;
                }


                switch (alt1) {
            	case 1 :
            	    // InternalStateMachineDsl.g:79:3: (lv_elements_0_0= ruleAbstractElement )
            	    {
            	    // InternalStateMachineDsl.g:79:3: (lv_elements_0_0= ruleAbstractElement )
            	    // InternalStateMachineDsl.g:80:4: lv_elements_0_0= ruleAbstractElement
            	    {

            	    				newCompositeNode(grammarAccess.getStateMachineAccess().getElementsAbstractElementParserRuleCall_0());
            	    			
            	    pushFollow(FOLLOW_3);
            	    lv_elements_0_0=ruleAbstractElement();

            	    state._fsp--;


            	    				if (current==null) {
            	    					current = createModelElementForParent(grammarAccess.getStateMachineRule());
            	    				}
            	    				add(
            	    					current,
            	    					"elements",
            	    					lv_elements_0_0,
            	    					"fr.su.StateMachineDsl.AbstractElement");
            	    				afterParserOrEnumRuleCall();
            	    			

            	    }


            	    }
            	    break;

            	default :
            	    break loop1;
                }
            } while (true);


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleStateMachine"


    // $ANTLR start "entryRuleAbstractElement"
    // InternalStateMachineDsl.g:100:1: entryRuleAbstractElement returns [EObject current=null] : iv_ruleAbstractElement= ruleAbstractElement EOF ;
    public final EObject entryRuleAbstractElement() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleAbstractElement = null;


        try {
            // InternalStateMachineDsl.g:100:56: (iv_ruleAbstractElement= ruleAbstractElement EOF )
            // InternalStateMachineDsl.g:101:2: iv_ruleAbstractElement= ruleAbstractElement EOF
            {
             newCompositeNode(grammarAccess.getAbstractElementRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleAbstractElement=ruleAbstractElement();

            state._fsp--;

             current =iv_ruleAbstractElement; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleAbstractElement"


    // $ANTLR start "ruleAbstractElement"
    // InternalStateMachineDsl.g:107:1: ruleAbstractElement returns [EObject current=null] : (this_StateMachineDeclaration_0= ruleStateMachineDeclaration | this_Label_1= ruleLabel | this_Node_2= ruleNode | this_Import_3= ruleImport | this_Input_4= ruleInput ) ;
    public final EObject ruleAbstractElement() throws RecognitionException {
        EObject current = null;

        EObject this_StateMachineDeclaration_0 = null;

        EObject this_Label_1 = null;

        EObject this_Node_2 = null;

        EObject this_Import_3 = null;

        EObject this_Input_4 = null;



        	enterRule();

        try {
            // InternalStateMachineDsl.g:113:2: ( (this_StateMachineDeclaration_0= ruleStateMachineDeclaration | this_Label_1= ruleLabel | this_Node_2= ruleNode | this_Import_3= ruleImport | this_Input_4= ruleInput ) )
            // InternalStateMachineDsl.g:114:2: (this_StateMachineDeclaration_0= ruleStateMachineDeclaration | this_Label_1= ruleLabel | this_Node_2= ruleNode | this_Import_3= ruleImport | this_Input_4= ruleInput )
            {
            // InternalStateMachineDsl.g:114:2: (this_StateMachineDeclaration_0= ruleStateMachineDeclaration | this_Label_1= ruleLabel | this_Node_2= ruleNode | this_Import_3= ruleImport | this_Input_4= ruleInput )
            int alt2=5;
            switch ( input.LA(1) ) {
            case 12:
                {
                alt2=1;
                }
                break;
            case 18:
            case 19:
                {
                alt2=2;
                }
                break;
            case 20:
            case 23:
                {
                alt2=3;
                }
                break;
            case 16:
                {
                alt2=4;
                }
                break;
            case 11:
                {
                alt2=5;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 2, 0, input);

                throw nvae;
            }

            switch (alt2) {
                case 1 :
                    // InternalStateMachineDsl.g:115:3: this_StateMachineDeclaration_0= ruleStateMachineDeclaration
                    {

                    			newCompositeNode(grammarAccess.getAbstractElementAccess().getStateMachineDeclarationParserRuleCall_0());
                    		
                    pushFollow(FOLLOW_2);
                    this_StateMachineDeclaration_0=ruleStateMachineDeclaration();

                    state._fsp--;


                    			current = this_StateMachineDeclaration_0;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 2 :
                    // InternalStateMachineDsl.g:124:3: this_Label_1= ruleLabel
                    {

                    			newCompositeNode(grammarAccess.getAbstractElementAccess().getLabelParserRuleCall_1());
                    		
                    pushFollow(FOLLOW_2);
                    this_Label_1=ruleLabel();

                    state._fsp--;


                    			current = this_Label_1;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 3 :
                    // InternalStateMachineDsl.g:133:3: this_Node_2= ruleNode
                    {

                    			newCompositeNode(grammarAccess.getAbstractElementAccess().getNodeParserRuleCall_2());
                    		
                    pushFollow(FOLLOW_2);
                    this_Node_2=ruleNode();

                    state._fsp--;


                    			current = this_Node_2;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 4 :
                    // InternalStateMachineDsl.g:142:3: this_Import_3= ruleImport
                    {

                    			newCompositeNode(grammarAccess.getAbstractElementAccess().getImportParserRuleCall_3());
                    		
                    pushFollow(FOLLOW_2);
                    this_Import_3=ruleImport();

                    state._fsp--;


                    			current = this_Import_3;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 5 :
                    // InternalStateMachineDsl.g:151:3: this_Input_4= ruleInput
                    {

                    			newCompositeNode(grammarAccess.getAbstractElementAccess().getInputParserRuleCall_4());
                    		
                    pushFollow(FOLLOW_2);
                    this_Input_4=ruleInput();

                    state._fsp--;


                    			current = this_Input_4;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleAbstractElement"


    // $ANTLR start "entryRuleInput"
    // InternalStateMachineDsl.g:163:1: entryRuleInput returns [EObject current=null] : iv_ruleInput= ruleInput EOF ;
    public final EObject entryRuleInput() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleInput = null;


        try {
            // InternalStateMachineDsl.g:163:46: (iv_ruleInput= ruleInput EOF )
            // InternalStateMachineDsl.g:164:2: iv_ruleInput= ruleInput EOF
            {
             newCompositeNode(grammarAccess.getInputRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleInput=ruleInput();

            state._fsp--;

             current =iv_ruleInput; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleInput"


    // $ANTLR start "ruleInput"
    // InternalStateMachineDsl.g:170:1: ruleInput returns [EObject current=null] : (otherlv_0= 'word' ( (lv_value_1_0= RULE_ID ) ) ) ;
    public final EObject ruleInput() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_value_1_0=null;


        	enterRule();

        try {
            // InternalStateMachineDsl.g:176:2: ( (otherlv_0= 'word' ( (lv_value_1_0= RULE_ID ) ) ) )
            // InternalStateMachineDsl.g:177:2: (otherlv_0= 'word' ( (lv_value_1_0= RULE_ID ) ) )
            {
            // InternalStateMachineDsl.g:177:2: (otherlv_0= 'word' ( (lv_value_1_0= RULE_ID ) ) )
            // InternalStateMachineDsl.g:178:3: otherlv_0= 'word' ( (lv_value_1_0= RULE_ID ) )
            {
            otherlv_0=(Token)match(input,11,FOLLOW_4); 

            			newLeafNode(otherlv_0, grammarAccess.getInputAccess().getWordKeyword_0());
            		
            // InternalStateMachineDsl.g:182:3: ( (lv_value_1_0= RULE_ID ) )
            // InternalStateMachineDsl.g:183:4: (lv_value_1_0= RULE_ID )
            {
            // InternalStateMachineDsl.g:183:4: (lv_value_1_0= RULE_ID )
            // InternalStateMachineDsl.g:184:5: lv_value_1_0= RULE_ID
            {
            lv_value_1_0=(Token)match(input,RULE_ID,FOLLOW_2); 

            					newLeafNode(lv_value_1_0, grammarAccess.getInputAccess().getValueIDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getInputRule());
            					}
            					setWithLastConsumed(
            						current,
            						"value",
            						lv_value_1_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleInput"


    // $ANTLR start "entryRuleStateMachineDeclaration"
    // InternalStateMachineDsl.g:204:1: entryRuleStateMachineDeclaration returns [EObject current=null] : iv_ruleStateMachineDeclaration= ruleStateMachineDeclaration EOF ;
    public final EObject entryRuleStateMachineDeclaration() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleStateMachineDeclaration = null;


        try {
            // InternalStateMachineDsl.g:204:64: (iv_ruleStateMachineDeclaration= ruleStateMachineDeclaration EOF )
            // InternalStateMachineDsl.g:205:2: iv_ruleStateMachineDeclaration= ruleStateMachineDeclaration EOF
            {
             newCompositeNode(grammarAccess.getStateMachineDeclarationRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleStateMachineDeclaration=ruleStateMachineDeclaration();

            state._fsp--;

             current =iv_ruleStateMachineDeclaration; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleStateMachineDeclaration"


    // $ANTLR start "ruleStateMachineDeclaration"
    // InternalStateMachineDsl.g:211:1: ruleStateMachineDeclaration returns [EObject current=null] : (otherlv_0= 'automaton' ( (lv_name_1_0= ruleQualifiedName ) ) otherlv_2= '{' ( (lv_elements_3_0= ruleAbstractElement ) )* otherlv_4= '}' ) ;
    public final EObject ruleStateMachineDeclaration() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_2=null;
        Token otherlv_4=null;
        AntlrDatatypeRuleToken lv_name_1_0 = null;

        EObject lv_elements_3_0 = null;



        	enterRule();

        try {
            // InternalStateMachineDsl.g:217:2: ( (otherlv_0= 'automaton' ( (lv_name_1_0= ruleQualifiedName ) ) otherlv_2= '{' ( (lv_elements_3_0= ruleAbstractElement ) )* otherlv_4= '}' ) )
            // InternalStateMachineDsl.g:218:2: (otherlv_0= 'automaton' ( (lv_name_1_0= ruleQualifiedName ) ) otherlv_2= '{' ( (lv_elements_3_0= ruleAbstractElement ) )* otherlv_4= '}' )
            {
            // InternalStateMachineDsl.g:218:2: (otherlv_0= 'automaton' ( (lv_name_1_0= ruleQualifiedName ) ) otherlv_2= '{' ( (lv_elements_3_0= ruleAbstractElement ) )* otherlv_4= '}' )
            // InternalStateMachineDsl.g:219:3: otherlv_0= 'automaton' ( (lv_name_1_0= ruleQualifiedName ) ) otherlv_2= '{' ( (lv_elements_3_0= ruleAbstractElement ) )* otherlv_4= '}'
            {
            otherlv_0=(Token)match(input,12,FOLLOW_4); 

            			newLeafNode(otherlv_0, grammarAccess.getStateMachineDeclarationAccess().getAutomatonKeyword_0());
            		
            // InternalStateMachineDsl.g:223:3: ( (lv_name_1_0= ruleQualifiedName ) )
            // InternalStateMachineDsl.g:224:4: (lv_name_1_0= ruleQualifiedName )
            {
            // InternalStateMachineDsl.g:224:4: (lv_name_1_0= ruleQualifiedName )
            // InternalStateMachineDsl.g:225:5: lv_name_1_0= ruleQualifiedName
            {

            					newCompositeNode(grammarAccess.getStateMachineDeclarationAccess().getNameQualifiedNameParserRuleCall_1_0());
            				
            pushFollow(FOLLOW_5);
            lv_name_1_0=ruleQualifiedName();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getStateMachineDeclarationRule());
            					}
            					set(
            						current,
            						"name",
            						lv_name_1_0,
            						"fr.su.StateMachineDsl.QualifiedName");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_2=(Token)match(input,13,FOLLOW_6); 

            			newLeafNode(otherlv_2, grammarAccess.getStateMachineDeclarationAccess().getLeftCurlyBracketKeyword_2());
            		
            // InternalStateMachineDsl.g:246:3: ( (lv_elements_3_0= ruleAbstractElement ) )*
            loop3:
            do {
                int alt3=2;
                int LA3_0 = input.LA(1);

                if ( ((LA3_0>=11 && LA3_0<=12)||LA3_0==16||(LA3_0>=18 && LA3_0<=20)||LA3_0==23) ) {
                    alt3=1;
                }


                switch (alt3) {
            	case 1 :
            	    // InternalStateMachineDsl.g:247:4: (lv_elements_3_0= ruleAbstractElement )
            	    {
            	    // InternalStateMachineDsl.g:247:4: (lv_elements_3_0= ruleAbstractElement )
            	    // InternalStateMachineDsl.g:248:5: lv_elements_3_0= ruleAbstractElement
            	    {

            	    					newCompositeNode(grammarAccess.getStateMachineDeclarationAccess().getElementsAbstractElementParserRuleCall_3_0());
            	    				
            	    pushFollow(FOLLOW_6);
            	    lv_elements_3_0=ruleAbstractElement();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getStateMachineDeclarationRule());
            	    					}
            	    					add(
            	    						current,
            	    						"elements",
            	    						lv_elements_3_0,
            	    						"fr.su.StateMachineDsl.AbstractElement");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop3;
                }
            } while (true);

            otherlv_4=(Token)match(input,14,FOLLOW_2); 

            			newLeafNode(otherlv_4, grammarAccess.getStateMachineDeclarationAccess().getRightCurlyBracketKeyword_4());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleStateMachineDeclaration"


    // $ANTLR start "entryRuleQualifiedName"
    // InternalStateMachineDsl.g:273:1: entryRuleQualifiedName returns [String current=null] : iv_ruleQualifiedName= ruleQualifiedName EOF ;
    public final String entryRuleQualifiedName() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleQualifiedName = null;


        try {
            // InternalStateMachineDsl.g:273:53: (iv_ruleQualifiedName= ruleQualifiedName EOF )
            // InternalStateMachineDsl.g:274:2: iv_ruleQualifiedName= ruleQualifiedName EOF
            {
             newCompositeNode(grammarAccess.getQualifiedNameRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleQualifiedName=ruleQualifiedName();

            state._fsp--;

             current =iv_ruleQualifiedName.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleQualifiedName"


    // $ANTLR start "ruleQualifiedName"
    // InternalStateMachineDsl.g:280:1: ruleQualifiedName returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : (this_ID_0= RULE_ID (kw= '.' this_ID_2= RULE_ID )* ) ;
    public final AntlrDatatypeRuleToken ruleQualifiedName() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token this_ID_0=null;
        Token kw=null;
        Token this_ID_2=null;


        	enterRule();

        try {
            // InternalStateMachineDsl.g:286:2: ( (this_ID_0= RULE_ID (kw= '.' this_ID_2= RULE_ID )* ) )
            // InternalStateMachineDsl.g:287:2: (this_ID_0= RULE_ID (kw= '.' this_ID_2= RULE_ID )* )
            {
            // InternalStateMachineDsl.g:287:2: (this_ID_0= RULE_ID (kw= '.' this_ID_2= RULE_ID )* )
            // InternalStateMachineDsl.g:288:3: this_ID_0= RULE_ID (kw= '.' this_ID_2= RULE_ID )*
            {
            this_ID_0=(Token)match(input,RULE_ID,FOLLOW_7); 

            			current.merge(this_ID_0);
            		

            			newLeafNode(this_ID_0, grammarAccess.getQualifiedNameAccess().getIDTerminalRuleCall_0());
            		
            // InternalStateMachineDsl.g:295:3: (kw= '.' this_ID_2= RULE_ID )*
            loop4:
            do {
                int alt4=2;
                int LA4_0 = input.LA(1);

                if ( (LA4_0==15) ) {
                    alt4=1;
                }


                switch (alt4) {
            	case 1 :
            	    // InternalStateMachineDsl.g:296:4: kw= '.' this_ID_2= RULE_ID
            	    {
            	    kw=(Token)match(input,15,FOLLOW_4); 

            	    				current.merge(kw);
            	    				newLeafNode(kw, grammarAccess.getQualifiedNameAccess().getFullStopKeyword_1_0());
            	    			
            	    this_ID_2=(Token)match(input,RULE_ID,FOLLOW_7); 

            	    				current.merge(this_ID_2);
            	    			

            	    				newLeafNode(this_ID_2, grammarAccess.getQualifiedNameAccess().getIDTerminalRuleCall_1_1());
            	    			

            	    }
            	    break;

            	default :
            	    break loop4;
                }
            } while (true);


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleQualifiedName"


    // $ANTLR start "entryRuleImport"
    // InternalStateMachineDsl.g:313:1: entryRuleImport returns [EObject current=null] : iv_ruleImport= ruleImport EOF ;
    public final EObject entryRuleImport() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleImport = null;


        try {
            // InternalStateMachineDsl.g:313:47: (iv_ruleImport= ruleImport EOF )
            // InternalStateMachineDsl.g:314:2: iv_ruleImport= ruleImport EOF
            {
             newCompositeNode(grammarAccess.getImportRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleImport=ruleImport();

            state._fsp--;

             current =iv_ruleImport; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleImport"


    // $ANTLR start "ruleImport"
    // InternalStateMachineDsl.g:320:1: ruleImport returns [EObject current=null] : (otherlv_0= 'import' ( (lv_importedNamespace_1_0= ruleQualifiedNameWithWildcard ) ) ) ;
    public final EObject ruleImport() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        AntlrDatatypeRuleToken lv_importedNamespace_1_0 = null;



        	enterRule();

        try {
            // InternalStateMachineDsl.g:326:2: ( (otherlv_0= 'import' ( (lv_importedNamespace_1_0= ruleQualifiedNameWithWildcard ) ) ) )
            // InternalStateMachineDsl.g:327:2: (otherlv_0= 'import' ( (lv_importedNamespace_1_0= ruleQualifiedNameWithWildcard ) ) )
            {
            // InternalStateMachineDsl.g:327:2: (otherlv_0= 'import' ( (lv_importedNamespace_1_0= ruleQualifiedNameWithWildcard ) ) )
            // InternalStateMachineDsl.g:328:3: otherlv_0= 'import' ( (lv_importedNamespace_1_0= ruleQualifiedNameWithWildcard ) )
            {
            otherlv_0=(Token)match(input,16,FOLLOW_4); 

            			newLeafNode(otherlv_0, grammarAccess.getImportAccess().getImportKeyword_0());
            		
            // InternalStateMachineDsl.g:332:3: ( (lv_importedNamespace_1_0= ruleQualifiedNameWithWildcard ) )
            // InternalStateMachineDsl.g:333:4: (lv_importedNamespace_1_0= ruleQualifiedNameWithWildcard )
            {
            // InternalStateMachineDsl.g:333:4: (lv_importedNamespace_1_0= ruleQualifiedNameWithWildcard )
            // InternalStateMachineDsl.g:334:5: lv_importedNamespace_1_0= ruleQualifiedNameWithWildcard
            {

            					newCompositeNode(grammarAccess.getImportAccess().getImportedNamespaceQualifiedNameWithWildcardParserRuleCall_1_0());
            				
            pushFollow(FOLLOW_2);
            lv_importedNamespace_1_0=ruleQualifiedNameWithWildcard();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getImportRule());
            					}
            					set(
            						current,
            						"importedNamespace",
            						lv_importedNamespace_1_0,
            						"fr.su.StateMachineDsl.QualifiedNameWithWildcard");
            					afterParserOrEnumRuleCall();
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleImport"


    // $ANTLR start "entryRuleQualifiedNameWithWildcard"
    // InternalStateMachineDsl.g:355:1: entryRuleQualifiedNameWithWildcard returns [String current=null] : iv_ruleQualifiedNameWithWildcard= ruleQualifiedNameWithWildcard EOF ;
    public final String entryRuleQualifiedNameWithWildcard() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleQualifiedNameWithWildcard = null;


        try {
            // InternalStateMachineDsl.g:355:65: (iv_ruleQualifiedNameWithWildcard= ruleQualifiedNameWithWildcard EOF )
            // InternalStateMachineDsl.g:356:2: iv_ruleQualifiedNameWithWildcard= ruleQualifiedNameWithWildcard EOF
            {
             newCompositeNode(grammarAccess.getQualifiedNameWithWildcardRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleQualifiedNameWithWildcard=ruleQualifiedNameWithWildcard();

            state._fsp--;

             current =iv_ruleQualifiedNameWithWildcard.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleQualifiedNameWithWildcard"


    // $ANTLR start "ruleQualifiedNameWithWildcard"
    // InternalStateMachineDsl.g:362:1: ruleQualifiedNameWithWildcard returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : (this_QualifiedName_0= ruleQualifiedName (kw= '.*' )? ) ;
    public final AntlrDatatypeRuleToken ruleQualifiedNameWithWildcard() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token kw=null;
        AntlrDatatypeRuleToken this_QualifiedName_0 = null;



        	enterRule();

        try {
            // InternalStateMachineDsl.g:368:2: ( (this_QualifiedName_0= ruleQualifiedName (kw= '.*' )? ) )
            // InternalStateMachineDsl.g:369:2: (this_QualifiedName_0= ruleQualifiedName (kw= '.*' )? )
            {
            // InternalStateMachineDsl.g:369:2: (this_QualifiedName_0= ruleQualifiedName (kw= '.*' )? )
            // InternalStateMachineDsl.g:370:3: this_QualifiedName_0= ruleQualifiedName (kw= '.*' )?
            {

            			newCompositeNode(grammarAccess.getQualifiedNameWithWildcardAccess().getQualifiedNameParserRuleCall_0());
            		
            pushFollow(FOLLOW_8);
            this_QualifiedName_0=ruleQualifiedName();

            state._fsp--;


            			current.merge(this_QualifiedName_0);
            		

            			afterParserOrEnumRuleCall();
            		
            // InternalStateMachineDsl.g:380:3: (kw= '.*' )?
            int alt5=2;
            int LA5_0 = input.LA(1);

            if ( (LA5_0==17) ) {
                alt5=1;
            }
            switch (alt5) {
                case 1 :
                    // InternalStateMachineDsl.g:381:4: kw= '.*'
                    {
                    kw=(Token)match(input,17,FOLLOW_2); 

                    				current.merge(kw);
                    				newLeafNode(kw, grammarAccess.getQualifiedNameWithWildcardAccess().getFullStopAsteriskKeyword_1());
                    			

                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleQualifiedNameWithWildcard"


    // $ANTLR start "entryRuleLabel"
    // InternalStateMachineDsl.g:391:1: entryRuleLabel returns [EObject current=null] : iv_ruleLabel= ruleLabel EOF ;
    public final EObject entryRuleLabel() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleLabel = null;


        try {
            // InternalStateMachineDsl.g:391:46: (iv_ruleLabel= ruleLabel EOF )
            // InternalStateMachineDsl.g:392:2: iv_ruleLabel= ruleLabel EOF
            {
             newCompositeNode(grammarAccess.getLabelRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleLabel=ruleLabel();

            state._fsp--;

             current =iv_ruleLabel; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleLabel"


    // $ANTLR start "ruleLabel"
    // InternalStateMachineDsl.g:398:1: ruleLabel returns [EObject current=null] : (this_SingleLabel_0= ruleSingleLabel | this_ListOfLabels_1= ruleListOfLabels ) ;
    public final EObject ruleLabel() throws RecognitionException {
        EObject current = null;

        EObject this_SingleLabel_0 = null;

        EObject this_ListOfLabels_1 = null;



        	enterRule();

        try {
            // InternalStateMachineDsl.g:404:2: ( (this_SingleLabel_0= ruleSingleLabel | this_ListOfLabels_1= ruleListOfLabels ) )
            // InternalStateMachineDsl.g:405:2: (this_SingleLabel_0= ruleSingleLabel | this_ListOfLabels_1= ruleListOfLabels )
            {
            // InternalStateMachineDsl.g:405:2: (this_SingleLabel_0= ruleSingleLabel | this_ListOfLabels_1= ruleListOfLabels )
            int alt6=2;
            int LA6_0 = input.LA(1);

            if ( (LA6_0==18) ) {
                alt6=1;
            }
            else if ( (LA6_0==19) ) {
                alt6=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 6, 0, input);

                throw nvae;
            }
            switch (alt6) {
                case 1 :
                    // InternalStateMachineDsl.g:406:3: this_SingleLabel_0= ruleSingleLabel
                    {

                    			newCompositeNode(grammarAccess.getLabelAccess().getSingleLabelParserRuleCall_0());
                    		
                    pushFollow(FOLLOW_2);
                    this_SingleLabel_0=ruleSingleLabel();

                    state._fsp--;


                    			current = this_SingleLabel_0;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 2 :
                    // InternalStateMachineDsl.g:415:3: this_ListOfLabels_1= ruleListOfLabels
                    {

                    			newCompositeNode(grammarAccess.getLabelAccess().getListOfLabelsParserRuleCall_1());
                    		
                    pushFollow(FOLLOW_2);
                    this_ListOfLabels_1=ruleListOfLabels();

                    state._fsp--;


                    			current = this_ListOfLabels_1;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleLabel"


    // $ANTLR start "entryRuleSingleLabel"
    // InternalStateMachineDsl.g:427:1: entryRuleSingleLabel returns [EObject current=null] : iv_ruleSingleLabel= ruleSingleLabel EOF ;
    public final EObject entryRuleSingleLabel() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleSingleLabel = null;


        try {
            // InternalStateMachineDsl.g:427:52: (iv_ruleSingleLabel= ruleSingleLabel EOF )
            // InternalStateMachineDsl.g:428:2: iv_ruleSingleLabel= ruleSingleLabel EOF
            {
             newCompositeNode(grammarAccess.getSingleLabelRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleSingleLabel=ruleSingleLabel();

            state._fsp--;

             current =iv_ruleSingleLabel; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleSingleLabel"


    // $ANTLR start "ruleSingleLabel"
    // InternalStateMachineDsl.g:434:1: ruleSingleLabel returns [EObject current=null] : (otherlv_0= 'label' ( (lv_label_1_0= ruleLabelName ) ) ) ;
    public final EObject ruleSingleLabel() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        EObject lv_label_1_0 = null;



        	enterRule();

        try {
            // InternalStateMachineDsl.g:440:2: ( (otherlv_0= 'label' ( (lv_label_1_0= ruleLabelName ) ) ) )
            // InternalStateMachineDsl.g:441:2: (otherlv_0= 'label' ( (lv_label_1_0= ruleLabelName ) ) )
            {
            // InternalStateMachineDsl.g:441:2: (otherlv_0= 'label' ( (lv_label_1_0= ruleLabelName ) ) )
            // InternalStateMachineDsl.g:442:3: otherlv_0= 'label' ( (lv_label_1_0= ruleLabelName ) )
            {
            otherlv_0=(Token)match(input,18,FOLLOW_4); 

            			newLeafNode(otherlv_0, grammarAccess.getSingleLabelAccess().getLabelKeyword_0());
            		
            // InternalStateMachineDsl.g:446:3: ( (lv_label_1_0= ruleLabelName ) )
            // InternalStateMachineDsl.g:447:4: (lv_label_1_0= ruleLabelName )
            {
            // InternalStateMachineDsl.g:447:4: (lv_label_1_0= ruleLabelName )
            // InternalStateMachineDsl.g:448:5: lv_label_1_0= ruleLabelName
            {

            					newCompositeNode(grammarAccess.getSingleLabelAccess().getLabelLabelNameParserRuleCall_1_0());
            				
            pushFollow(FOLLOW_2);
            lv_label_1_0=ruleLabelName();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getSingleLabelRule());
            					}
            					set(
            						current,
            						"label",
            						lv_label_1_0,
            						"fr.su.StateMachineDsl.LabelName");
            					afterParserOrEnumRuleCall();
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleSingleLabel"


    // $ANTLR start "entryRuleListOfLabels"
    // InternalStateMachineDsl.g:469:1: entryRuleListOfLabels returns [EObject current=null] : iv_ruleListOfLabels= ruleListOfLabels EOF ;
    public final EObject entryRuleListOfLabels() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleListOfLabels = null;


        try {
            // InternalStateMachineDsl.g:469:53: (iv_ruleListOfLabels= ruleListOfLabels EOF )
            // InternalStateMachineDsl.g:470:2: iv_ruleListOfLabels= ruleListOfLabels EOF
            {
             newCompositeNode(grammarAccess.getListOfLabelsRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleListOfLabels=ruleListOfLabels();

            state._fsp--;

             current =iv_ruleListOfLabels; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleListOfLabels"


    // $ANTLR start "ruleListOfLabels"
    // InternalStateMachineDsl.g:476:1: ruleListOfLabels returns [EObject current=null] : (otherlv_0= 'labels' ( (lv_labels_1_0= ruleLabelName ) )+ ) ;
    public final EObject ruleListOfLabels() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        EObject lv_labels_1_0 = null;



        	enterRule();

        try {
            // InternalStateMachineDsl.g:482:2: ( (otherlv_0= 'labels' ( (lv_labels_1_0= ruleLabelName ) )+ ) )
            // InternalStateMachineDsl.g:483:2: (otherlv_0= 'labels' ( (lv_labels_1_0= ruleLabelName ) )+ )
            {
            // InternalStateMachineDsl.g:483:2: (otherlv_0= 'labels' ( (lv_labels_1_0= ruleLabelName ) )+ )
            // InternalStateMachineDsl.g:484:3: otherlv_0= 'labels' ( (lv_labels_1_0= ruleLabelName ) )+
            {
            otherlv_0=(Token)match(input,19,FOLLOW_4); 

            			newLeafNode(otherlv_0, grammarAccess.getListOfLabelsAccess().getLabelsKeyword_0());
            		
            // InternalStateMachineDsl.g:488:3: ( (lv_labels_1_0= ruleLabelName ) )+
            int cnt7=0;
            loop7:
            do {
                int alt7=2;
                int LA7_0 = input.LA(1);

                if ( (LA7_0==RULE_ID) ) {
                    alt7=1;
                }


                switch (alt7) {
            	case 1 :
            	    // InternalStateMachineDsl.g:489:4: (lv_labels_1_0= ruleLabelName )
            	    {
            	    // InternalStateMachineDsl.g:489:4: (lv_labels_1_0= ruleLabelName )
            	    // InternalStateMachineDsl.g:490:5: lv_labels_1_0= ruleLabelName
            	    {

            	    					newCompositeNode(grammarAccess.getListOfLabelsAccess().getLabelsLabelNameParserRuleCall_1_0());
            	    				
            	    pushFollow(FOLLOW_9);
            	    lv_labels_1_0=ruleLabelName();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getListOfLabelsRule());
            	    					}
            	    					add(
            	    						current,
            	    						"labels",
            	    						lv_labels_1_0,
            	    						"fr.su.StateMachineDsl.LabelName");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    if ( cnt7 >= 1 ) break loop7;
                        EarlyExitException eee =
                            new EarlyExitException(7, input);
                        throw eee;
                }
                cnt7++;
            } while (true);


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleListOfLabels"


    // $ANTLR start "entryRuleLabelName"
    // InternalStateMachineDsl.g:511:1: entryRuleLabelName returns [EObject current=null] : iv_ruleLabelName= ruleLabelName EOF ;
    public final EObject entryRuleLabelName() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleLabelName = null;


        try {
            // InternalStateMachineDsl.g:511:50: (iv_ruleLabelName= ruleLabelName EOF )
            // InternalStateMachineDsl.g:512:2: iv_ruleLabelName= ruleLabelName EOF
            {
             newCompositeNode(grammarAccess.getLabelNameRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleLabelName=ruleLabelName();

            state._fsp--;

             current =iv_ruleLabelName; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleLabelName"


    // $ANTLR start "ruleLabelName"
    // InternalStateMachineDsl.g:518:1: ruleLabelName returns [EObject current=null] : ( (lv_name_0_0= RULE_ID ) ) ;
    public final EObject ruleLabelName() throws RecognitionException {
        EObject current = null;

        Token lv_name_0_0=null;


        	enterRule();

        try {
            // InternalStateMachineDsl.g:524:2: ( ( (lv_name_0_0= RULE_ID ) ) )
            // InternalStateMachineDsl.g:525:2: ( (lv_name_0_0= RULE_ID ) )
            {
            // InternalStateMachineDsl.g:525:2: ( (lv_name_0_0= RULE_ID ) )
            // InternalStateMachineDsl.g:526:3: (lv_name_0_0= RULE_ID )
            {
            // InternalStateMachineDsl.g:526:3: (lv_name_0_0= RULE_ID )
            // InternalStateMachineDsl.g:527:4: lv_name_0_0= RULE_ID
            {
            lv_name_0_0=(Token)match(input,RULE_ID,FOLLOW_2); 

            				newLeafNode(lv_name_0_0, grammarAccess.getLabelNameAccess().getNameIDTerminalRuleCall_0());
            			

            				if (current==null) {
            					current = createModelElement(grammarAccess.getLabelNameRule());
            				}
            				setWithLastConsumed(
            					current,
            					"name",
            					lv_name_0_0,
            					"org.eclipse.xtext.common.Terminals.ID");
            			

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleLabelName"


    // $ANTLR start "entryRuleNode"
    // InternalStateMachineDsl.g:546:1: entryRuleNode returns [EObject current=null] : iv_ruleNode= ruleNode EOF ;
    public final EObject entryRuleNode() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleNode = null;


        try {
            // InternalStateMachineDsl.g:546:45: (iv_ruleNode= ruleNode EOF )
            // InternalStateMachineDsl.g:547:2: iv_ruleNode= ruleNode EOF
            {
             newCompositeNode(grammarAccess.getNodeRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleNode=ruleNode();

            state._fsp--;

             current =iv_ruleNode; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleNode"


    // $ANTLR start "ruleNode"
    // InternalStateMachineDsl.g:553:1: ruleNode returns [EObject current=null] : (this_State_0= ruleState | this_Transition_1= ruleTransition ) ;
    public final EObject ruleNode() throws RecognitionException {
        EObject current = null;

        EObject this_State_0 = null;

        EObject this_Transition_1 = null;



        	enterRule();

        try {
            // InternalStateMachineDsl.g:559:2: ( (this_State_0= ruleState | this_Transition_1= ruleTransition ) )
            // InternalStateMachineDsl.g:560:2: (this_State_0= ruleState | this_Transition_1= ruleTransition )
            {
            // InternalStateMachineDsl.g:560:2: (this_State_0= ruleState | this_Transition_1= ruleTransition )
            int alt8=2;
            int LA8_0 = input.LA(1);

            if ( (LA8_0==20) ) {
                alt8=1;
            }
            else if ( (LA8_0==23) ) {
                alt8=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 8, 0, input);

                throw nvae;
            }
            switch (alt8) {
                case 1 :
                    // InternalStateMachineDsl.g:561:3: this_State_0= ruleState
                    {

                    			newCompositeNode(grammarAccess.getNodeAccess().getStateParserRuleCall_0());
                    		
                    pushFollow(FOLLOW_2);
                    this_State_0=ruleState();

                    state._fsp--;


                    			current = this_State_0;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 2 :
                    // InternalStateMachineDsl.g:570:3: this_Transition_1= ruleTransition
                    {

                    			newCompositeNode(grammarAccess.getNodeAccess().getTransitionParserRuleCall_1());
                    		
                    pushFollow(FOLLOW_2);
                    this_Transition_1=ruleTransition();

                    state._fsp--;


                    			current = this_Transition_1;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleNode"


    // $ANTLR start "entryRuleState"
    // InternalStateMachineDsl.g:582:1: entryRuleState returns [EObject current=null] : iv_ruleState= ruleState EOF ;
    public final EObject entryRuleState() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleState = null;


        try {
            // InternalStateMachineDsl.g:582:46: (iv_ruleState= ruleState EOF )
            // InternalStateMachineDsl.g:583:2: iv_ruleState= ruleState EOF
            {
             newCompositeNode(grammarAccess.getStateRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleState=ruleState();

            state._fsp--;

             current =iv_ruleState; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleState"


    // $ANTLR start "ruleState"
    // InternalStateMachineDsl.g:589:1: ruleState returns [EObject current=null] : ( () otherlv_1= 'state' ( (lv_name_2_0= RULE_ID ) ) otherlv_3= '{' ( ( (lv_isFinal_4_0= 'final' ) )? | ( (lv_isInitial_5_0= 'initial' ) )? ) otherlv_6= '}' ) ;
    public final EObject ruleState() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        Token lv_name_2_0=null;
        Token otherlv_3=null;
        Token lv_isFinal_4_0=null;
        Token lv_isInitial_5_0=null;
        Token otherlv_6=null;


        	enterRule();

        try {
            // InternalStateMachineDsl.g:595:2: ( ( () otherlv_1= 'state' ( (lv_name_2_0= RULE_ID ) ) otherlv_3= '{' ( ( (lv_isFinal_4_0= 'final' ) )? | ( (lv_isInitial_5_0= 'initial' ) )? ) otherlv_6= '}' ) )
            // InternalStateMachineDsl.g:596:2: ( () otherlv_1= 'state' ( (lv_name_2_0= RULE_ID ) ) otherlv_3= '{' ( ( (lv_isFinal_4_0= 'final' ) )? | ( (lv_isInitial_5_0= 'initial' ) )? ) otherlv_6= '}' )
            {
            // InternalStateMachineDsl.g:596:2: ( () otherlv_1= 'state' ( (lv_name_2_0= RULE_ID ) ) otherlv_3= '{' ( ( (lv_isFinal_4_0= 'final' ) )? | ( (lv_isInitial_5_0= 'initial' ) )? ) otherlv_6= '}' )
            // InternalStateMachineDsl.g:597:3: () otherlv_1= 'state' ( (lv_name_2_0= RULE_ID ) ) otherlv_3= '{' ( ( (lv_isFinal_4_0= 'final' ) )? | ( (lv_isInitial_5_0= 'initial' ) )? ) otherlv_6= '}'
            {
            // InternalStateMachineDsl.g:597:3: ()
            // InternalStateMachineDsl.g:598:4: 
            {

            				current = forceCreateModelElement(
            					grammarAccess.getStateAccess().getStateAction_0(),
            					current);
            			

            }

            otherlv_1=(Token)match(input,20,FOLLOW_4); 

            			newLeafNode(otherlv_1, grammarAccess.getStateAccess().getStateKeyword_1());
            		
            // InternalStateMachineDsl.g:608:3: ( (lv_name_2_0= RULE_ID ) )
            // InternalStateMachineDsl.g:609:4: (lv_name_2_0= RULE_ID )
            {
            // InternalStateMachineDsl.g:609:4: (lv_name_2_0= RULE_ID )
            // InternalStateMachineDsl.g:610:5: lv_name_2_0= RULE_ID
            {
            lv_name_2_0=(Token)match(input,RULE_ID,FOLLOW_5); 

            					newLeafNode(lv_name_2_0, grammarAccess.getStateAccess().getNameIDTerminalRuleCall_2_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getStateRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_2_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_3=(Token)match(input,13,FOLLOW_10); 

            			newLeafNode(otherlv_3, grammarAccess.getStateAccess().getLeftCurlyBracketKeyword_3());
            		
            // InternalStateMachineDsl.g:630:3: ( ( (lv_isFinal_4_0= 'final' ) )? | ( (lv_isInitial_5_0= 'initial' ) )? )
            int alt11=2;
            switch ( input.LA(1) ) {
            case 21:
                {
                alt11=1;
                }
                break;
            case 14:
                {
                alt11=1;
                }
                break;
            case 22:
                {
                alt11=2;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 11, 0, input);

                throw nvae;
            }

            switch (alt11) {
                case 1 :
                    // InternalStateMachineDsl.g:631:4: ( (lv_isFinal_4_0= 'final' ) )?
                    {
                    // InternalStateMachineDsl.g:631:4: ( (lv_isFinal_4_0= 'final' ) )?
                    int alt9=2;
                    int LA9_0 = input.LA(1);

                    if ( (LA9_0==21) ) {
                        alt9=1;
                    }
                    switch (alt9) {
                        case 1 :
                            // InternalStateMachineDsl.g:632:5: (lv_isFinal_4_0= 'final' )
                            {
                            // InternalStateMachineDsl.g:632:5: (lv_isFinal_4_0= 'final' )
                            // InternalStateMachineDsl.g:633:6: lv_isFinal_4_0= 'final'
                            {
                            lv_isFinal_4_0=(Token)match(input,21,FOLLOW_11); 

                            						newLeafNode(lv_isFinal_4_0, grammarAccess.getStateAccess().getIsFinalFinalKeyword_4_0_0());
                            					

                            						if (current==null) {
                            							current = createModelElement(grammarAccess.getStateRule());
                            						}
                            						setWithLastConsumed(current, "isFinal", lv_isFinal_4_0 != null, "final");
                            					

                            }


                            }
                            break;

                    }


                    }
                    break;
                case 2 :
                    // InternalStateMachineDsl.g:646:4: ( (lv_isInitial_5_0= 'initial' ) )?
                    {
                    // InternalStateMachineDsl.g:646:4: ( (lv_isInitial_5_0= 'initial' ) )?
                    int alt10=2;
                    int LA10_0 = input.LA(1);

                    if ( (LA10_0==22) ) {
                        alt10=1;
                    }
                    switch (alt10) {
                        case 1 :
                            // InternalStateMachineDsl.g:647:5: (lv_isInitial_5_0= 'initial' )
                            {
                            // InternalStateMachineDsl.g:647:5: (lv_isInitial_5_0= 'initial' )
                            // InternalStateMachineDsl.g:648:6: lv_isInitial_5_0= 'initial'
                            {
                            lv_isInitial_5_0=(Token)match(input,22,FOLLOW_11); 

                            						newLeafNode(lv_isInitial_5_0, grammarAccess.getStateAccess().getIsInitialInitialKeyword_4_1_0());
                            					

                            						if (current==null) {
                            							current = createModelElement(grammarAccess.getStateRule());
                            						}
                            						setWithLastConsumed(current, "isInitial", lv_isInitial_5_0 != null, "initial");
                            					

                            }


                            }
                            break;

                    }


                    }
                    break;

            }

            otherlv_6=(Token)match(input,14,FOLLOW_2); 

            			newLeafNode(otherlv_6, grammarAccess.getStateAccess().getRightCurlyBracketKeyword_5());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleState"


    // $ANTLR start "entryRuleTransition"
    // InternalStateMachineDsl.g:669:1: entryRuleTransition returns [EObject current=null] : iv_ruleTransition= ruleTransition EOF ;
    public final EObject entryRuleTransition() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleTransition = null;


        try {
            // InternalStateMachineDsl.g:669:51: (iv_ruleTransition= ruleTransition EOF )
            // InternalStateMachineDsl.g:670:2: iv_ruleTransition= ruleTransition EOF
            {
             newCompositeNode(grammarAccess.getTransitionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleTransition=ruleTransition();

            state._fsp--;

             current =iv_ruleTransition; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleTransition"


    // $ANTLR start "ruleTransition"
    // InternalStateMachineDsl.g:676:1: ruleTransition returns [EObject current=null] : (otherlv_0= 'transition' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' otherlv_3= 'event' ( (otherlv_4= RULE_ID ) ) otherlv_5= 'from' ( (otherlv_6= RULE_ID ) ) otherlv_7= 'to' ( (otherlv_8= RULE_ID ) ) otherlv_9= '}' ) ;
    public final EObject ruleTransition() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;
        Token otherlv_2=null;
        Token otherlv_3=null;
        Token otherlv_4=null;
        Token otherlv_5=null;
        Token otherlv_6=null;
        Token otherlv_7=null;
        Token otherlv_8=null;
        Token otherlv_9=null;


        	enterRule();

        try {
            // InternalStateMachineDsl.g:682:2: ( (otherlv_0= 'transition' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' otherlv_3= 'event' ( (otherlv_4= RULE_ID ) ) otherlv_5= 'from' ( (otherlv_6= RULE_ID ) ) otherlv_7= 'to' ( (otherlv_8= RULE_ID ) ) otherlv_9= '}' ) )
            // InternalStateMachineDsl.g:683:2: (otherlv_0= 'transition' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' otherlv_3= 'event' ( (otherlv_4= RULE_ID ) ) otherlv_5= 'from' ( (otherlv_6= RULE_ID ) ) otherlv_7= 'to' ( (otherlv_8= RULE_ID ) ) otherlv_9= '}' )
            {
            // InternalStateMachineDsl.g:683:2: (otherlv_0= 'transition' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' otherlv_3= 'event' ( (otherlv_4= RULE_ID ) ) otherlv_5= 'from' ( (otherlv_6= RULE_ID ) ) otherlv_7= 'to' ( (otherlv_8= RULE_ID ) ) otherlv_9= '}' )
            // InternalStateMachineDsl.g:684:3: otherlv_0= 'transition' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' otherlv_3= 'event' ( (otherlv_4= RULE_ID ) ) otherlv_5= 'from' ( (otherlv_6= RULE_ID ) ) otherlv_7= 'to' ( (otherlv_8= RULE_ID ) ) otherlv_9= '}'
            {
            otherlv_0=(Token)match(input,23,FOLLOW_4); 

            			newLeafNode(otherlv_0, grammarAccess.getTransitionAccess().getTransitionKeyword_0());
            		
            // InternalStateMachineDsl.g:688:3: ( (lv_name_1_0= RULE_ID ) )
            // InternalStateMachineDsl.g:689:4: (lv_name_1_0= RULE_ID )
            {
            // InternalStateMachineDsl.g:689:4: (lv_name_1_0= RULE_ID )
            // InternalStateMachineDsl.g:690:5: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_5); 

            					newLeafNode(lv_name_1_0, grammarAccess.getTransitionAccess().getNameIDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getTransitionRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_1_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_2=(Token)match(input,13,FOLLOW_12); 

            			newLeafNode(otherlv_2, grammarAccess.getTransitionAccess().getLeftCurlyBracketKeyword_2());
            		
            otherlv_3=(Token)match(input,24,FOLLOW_4); 

            			newLeafNode(otherlv_3, grammarAccess.getTransitionAccess().getEventKeyword_3());
            		
            // InternalStateMachineDsl.g:714:3: ( (otherlv_4= RULE_ID ) )
            // InternalStateMachineDsl.g:715:4: (otherlv_4= RULE_ID )
            {
            // InternalStateMachineDsl.g:715:4: (otherlv_4= RULE_ID )
            // InternalStateMachineDsl.g:716:5: otherlv_4= RULE_ID
            {

            					if (current==null) {
            						current = createModelElement(grammarAccess.getTransitionRule());
            					}
            				
            otherlv_4=(Token)match(input,RULE_ID,FOLLOW_13); 

            					newLeafNode(otherlv_4, grammarAccess.getTransitionAccess().getTypeLabelNameCrossReference_4_0());
            				

            }


            }

            otherlv_5=(Token)match(input,25,FOLLOW_4); 

            			newLeafNode(otherlv_5, grammarAccess.getTransitionAccess().getFromKeyword_5());
            		
            // InternalStateMachineDsl.g:731:3: ( (otherlv_6= RULE_ID ) )
            // InternalStateMachineDsl.g:732:4: (otherlv_6= RULE_ID )
            {
            // InternalStateMachineDsl.g:732:4: (otherlv_6= RULE_ID )
            // InternalStateMachineDsl.g:733:5: otherlv_6= RULE_ID
            {

            					if (current==null) {
            						current = createModelElement(grammarAccess.getTransitionRule());
            					}
            				
            otherlv_6=(Token)match(input,RULE_ID,FOLLOW_14); 

            					newLeafNode(otherlv_6, grammarAccess.getTransitionAccess().getSourceStateCrossReference_6_0());
            				

            }


            }

            otherlv_7=(Token)match(input,26,FOLLOW_4); 

            			newLeafNode(otherlv_7, grammarAccess.getTransitionAccess().getToKeyword_7());
            		
            // InternalStateMachineDsl.g:748:3: ( (otherlv_8= RULE_ID ) )
            // InternalStateMachineDsl.g:749:4: (otherlv_8= RULE_ID )
            {
            // InternalStateMachineDsl.g:749:4: (otherlv_8= RULE_ID )
            // InternalStateMachineDsl.g:750:5: otherlv_8= RULE_ID
            {

            					if (current==null) {
            						current = createModelElement(grammarAccess.getTransitionRule());
            					}
            				
            otherlv_8=(Token)match(input,RULE_ID,FOLLOW_11); 

            					newLeafNode(otherlv_8, grammarAccess.getTransitionAccess().getTargetStateCrossReference_8_0());
            				

            }


            }

            otherlv_9=(Token)match(input,14,FOLLOW_2); 

            			newLeafNode(otherlv_9, grammarAccess.getTransitionAccess().getRightCurlyBracketKeyword_9());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleTransition"

    // Delegated rules


 

    public static final BitSet FOLLOW_1 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_2 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_3 = new BitSet(new long[]{0x00000000009D1802L});
    public static final BitSet FOLLOW_4 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_5 = new BitSet(new long[]{0x0000000000002000L});
    public static final BitSet FOLLOW_6 = new BitSet(new long[]{0x00000000009D5800L});
    public static final BitSet FOLLOW_7 = new BitSet(new long[]{0x0000000000008002L});
    public static final BitSet FOLLOW_8 = new BitSet(new long[]{0x0000000000020002L});
    public static final BitSet FOLLOW_9 = new BitSet(new long[]{0x0000000000000012L});
    public static final BitSet FOLLOW_10 = new BitSet(new long[]{0x0000000000604000L});
    public static final BitSet FOLLOW_11 = new BitSet(new long[]{0x0000000000004000L});
    public static final BitSet FOLLOW_12 = new BitSet(new long[]{0x0000000001000000L});
    public static final BitSet FOLLOW_13 = new BitSet(new long[]{0x0000000002000000L});
    public static final BitSet FOLLOW_14 = new BitSet(new long[]{0x0000000004000000L});

}