package fr.su.ide.contentassist.antlr.internal;

import java.io.InputStream;
import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.ide.editor.contentassist.antlr.internal.AbstractInternalContentAssistParser;
import org.eclipse.xtext.ide.editor.contentassist.antlr.internal.DFA;
import fr.su.services.StateMachineDslGrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings("all")
public class InternalStateMachineDslParser extends AbstractInternalContentAssistParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_ID", "RULE_INT", "RULE_STRING", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "RULE_WS", "RULE_ANY_OTHER", "'word'", "'automaton'", "'{'", "'}'", "'.'", "'import'", "'.*'", "'label'", "'labels'", "'state'", "'transition'", "'event'", "'from'", "'to'", "'final'", "'initial'"
    };
    public static final int RULE_STRING=6;
    public static final int RULE_SL_COMMENT=8;
    public static final int T__19=19;
    public static final int T__15=15;
    public static final int T__16=16;
    public static final int T__17=17;
    public static final int T__18=18;
    public static final int T__11=11;
    public static final int T__12=12;
    public static final int T__13=13;
    public static final int T__14=14;
    public static final int EOF=-1;
    public static final int RULE_ID=4;
    public static final int RULE_WS=9;
    public static final int RULE_ANY_OTHER=10;
    public static final int T__26=26;
    public static final int RULE_INT=5;
    public static final int T__22=22;
    public static final int RULE_ML_COMMENT=7;
    public static final int T__23=23;
    public static final int T__24=24;
    public static final int T__25=25;
    public static final int T__20=20;
    public static final int T__21=21;

    // delegates
    // delegators


        public InternalStateMachineDslParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public InternalStateMachineDslParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return InternalStateMachineDslParser.tokenNames; }
    public String getGrammarFileName() { return "InternalStateMachineDsl.g"; }


    	private StateMachineDslGrammarAccess grammarAccess;

    	public void setGrammarAccess(StateMachineDslGrammarAccess grammarAccess) {
    		this.grammarAccess = grammarAccess;
    	}

    	@Override
    	protected Grammar getGrammar() {
    		return grammarAccess.getGrammar();
    	}

    	@Override
    	protected String getValueForTokenName(String tokenName) {
    		return tokenName;
    	}



    // $ANTLR start "entryRuleStateMachine"
    // InternalStateMachineDsl.g:53:1: entryRuleStateMachine : ruleStateMachine EOF ;
    public final void entryRuleStateMachine() throws RecognitionException {
        try {
            // InternalStateMachineDsl.g:54:1: ( ruleStateMachine EOF )
            // InternalStateMachineDsl.g:55:1: ruleStateMachine EOF
            {
             before(grammarAccess.getStateMachineRule()); 
            pushFollow(FOLLOW_1);
            ruleStateMachine();

            state._fsp--;

             after(grammarAccess.getStateMachineRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleStateMachine"


    // $ANTLR start "ruleStateMachine"
    // InternalStateMachineDsl.g:62:1: ruleStateMachine : ( ( rule__StateMachine__ElementsAssignment )* ) ;
    public final void ruleStateMachine() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalStateMachineDsl.g:66:2: ( ( ( rule__StateMachine__ElementsAssignment )* ) )
            // InternalStateMachineDsl.g:67:2: ( ( rule__StateMachine__ElementsAssignment )* )
            {
            // InternalStateMachineDsl.g:67:2: ( ( rule__StateMachine__ElementsAssignment )* )
            // InternalStateMachineDsl.g:68:3: ( rule__StateMachine__ElementsAssignment )*
            {
             before(grammarAccess.getStateMachineAccess().getElementsAssignment()); 
            // InternalStateMachineDsl.g:69:3: ( rule__StateMachine__ElementsAssignment )*
            loop1:
            do {
                int alt1=2;
                int LA1_0 = input.LA(1);

                if ( ((LA1_0>=11 && LA1_0<=12)||LA1_0==16||(LA1_0>=18 && LA1_0<=21)) ) {
                    alt1=1;
                }


                switch (alt1) {
            	case 1 :
            	    // InternalStateMachineDsl.g:69:4: rule__StateMachine__ElementsAssignment
            	    {
            	    pushFollow(FOLLOW_3);
            	    rule__StateMachine__ElementsAssignment();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop1;
                }
            } while (true);

             after(grammarAccess.getStateMachineAccess().getElementsAssignment()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleStateMachine"


    // $ANTLR start "entryRuleAbstractElement"
    // InternalStateMachineDsl.g:78:1: entryRuleAbstractElement : ruleAbstractElement EOF ;
    public final void entryRuleAbstractElement() throws RecognitionException {
        try {
            // InternalStateMachineDsl.g:79:1: ( ruleAbstractElement EOF )
            // InternalStateMachineDsl.g:80:1: ruleAbstractElement EOF
            {
             before(grammarAccess.getAbstractElementRule()); 
            pushFollow(FOLLOW_1);
            ruleAbstractElement();

            state._fsp--;

             after(grammarAccess.getAbstractElementRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleAbstractElement"


    // $ANTLR start "ruleAbstractElement"
    // InternalStateMachineDsl.g:87:1: ruleAbstractElement : ( ( rule__AbstractElement__Alternatives ) ) ;
    public final void ruleAbstractElement() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalStateMachineDsl.g:91:2: ( ( ( rule__AbstractElement__Alternatives ) ) )
            // InternalStateMachineDsl.g:92:2: ( ( rule__AbstractElement__Alternatives ) )
            {
            // InternalStateMachineDsl.g:92:2: ( ( rule__AbstractElement__Alternatives ) )
            // InternalStateMachineDsl.g:93:3: ( rule__AbstractElement__Alternatives )
            {
             before(grammarAccess.getAbstractElementAccess().getAlternatives()); 
            // InternalStateMachineDsl.g:94:3: ( rule__AbstractElement__Alternatives )
            // InternalStateMachineDsl.g:94:4: rule__AbstractElement__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__AbstractElement__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getAbstractElementAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleAbstractElement"


    // $ANTLR start "entryRuleInput"
    // InternalStateMachineDsl.g:103:1: entryRuleInput : ruleInput EOF ;
    public final void entryRuleInput() throws RecognitionException {
        try {
            // InternalStateMachineDsl.g:104:1: ( ruleInput EOF )
            // InternalStateMachineDsl.g:105:1: ruleInput EOF
            {
             before(grammarAccess.getInputRule()); 
            pushFollow(FOLLOW_1);
            ruleInput();

            state._fsp--;

             after(grammarAccess.getInputRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleInput"


    // $ANTLR start "ruleInput"
    // InternalStateMachineDsl.g:112:1: ruleInput : ( ( rule__Input__Group__0 ) ) ;
    public final void ruleInput() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalStateMachineDsl.g:116:2: ( ( ( rule__Input__Group__0 ) ) )
            // InternalStateMachineDsl.g:117:2: ( ( rule__Input__Group__0 ) )
            {
            // InternalStateMachineDsl.g:117:2: ( ( rule__Input__Group__0 ) )
            // InternalStateMachineDsl.g:118:3: ( rule__Input__Group__0 )
            {
             before(grammarAccess.getInputAccess().getGroup()); 
            // InternalStateMachineDsl.g:119:3: ( rule__Input__Group__0 )
            // InternalStateMachineDsl.g:119:4: rule__Input__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Input__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getInputAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleInput"


    // $ANTLR start "entryRuleStateMachineDeclaration"
    // InternalStateMachineDsl.g:128:1: entryRuleStateMachineDeclaration : ruleStateMachineDeclaration EOF ;
    public final void entryRuleStateMachineDeclaration() throws RecognitionException {
        try {
            // InternalStateMachineDsl.g:129:1: ( ruleStateMachineDeclaration EOF )
            // InternalStateMachineDsl.g:130:1: ruleStateMachineDeclaration EOF
            {
             before(grammarAccess.getStateMachineDeclarationRule()); 
            pushFollow(FOLLOW_1);
            ruleStateMachineDeclaration();

            state._fsp--;

             after(grammarAccess.getStateMachineDeclarationRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleStateMachineDeclaration"


    // $ANTLR start "ruleStateMachineDeclaration"
    // InternalStateMachineDsl.g:137:1: ruleStateMachineDeclaration : ( ( rule__StateMachineDeclaration__Group__0 ) ) ;
    public final void ruleStateMachineDeclaration() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalStateMachineDsl.g:141:2: ( ( ( rule__StateMachineDeclaration__Group__0 ) ) )
            // InternalStateMachineDsl.g:142:2: ( ( rule__StateMachineDeclaration__Group__0 ) )
            {
            // InternalStateMachineDsl.g:142:2: ( ( rule__StateMachineDeclaration__Group__0 ) )
            // InternalStateMachineDsl.g:143:3: ( rule__StateMachineDeclaration__Group__0 )
            {
             before(grammarAccess.getStateMachineDeclarationAccess().getGroup()); 
            // InternalStateMachineDsl.g:144:3: ( rule__StateMachineDeclaration__Group__0 )
            // InternalStateMachineDsl.g:144:4: rule__StateMachineDeclaration__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__StateMachineDeclaration__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getStateMachineDeclarationAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleStateMachineDeclaration"


    // $ANTLR start "entryRuleQualifiedName"
    // InternalStateMachineDsl.g:153:1: entryRuleQualifiedName : ruleQualifiedName EOF ;
    public final void entryRuleQualifiedName() throws RecognitionException {
        try {
            // InternalStateMachineDsl.g:154:1: ( ruleQualifiedName EOF )
            // InternalStateMachineDsl.g:155:1: ruleQualifiedName EOF
            {
             before(grammarAccess.getQualifiedNameRule()); 
            pushFollow(FOLLOW_1);
            ruleQualifiedName();

            state._fsp--;

             after(grammarAccess.getQualifiedNameRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleQualifiedName"


    // $ANTLR start "ruleQualifiedName"
    // InternalStateMachineDsl.g:162:1: ruleQualifiedName : ( ( rule__QualifiedName__Group__0 ) ) ;
    public final void ruleQualifiedName() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalStateMachineDsl.g:166:2: ( ( ( rule__QualifiedName__Group__0 ) ) )
            // InternalStateMachineDsl.g:167:2: ( ( rule__QualifiedName__Group__0 ) )
            {
            // InternalStateMachineDsl.g:167:2: ( ( rule__QualifiedName__Group__0 ) )
            // InternalStateMachineDsl.g:168:3: ( rule__QualifiedName__Group__0 )
            {
             before(grammarAccess.getQualifiedNameAccess().getGroup()); 
            // InternalStateMachineDsl.g:169:3: ( rule__QualifiedName__Group__0 )
            // InternalStateMachineDsl.g:169:4: rule__QualifiedName__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__QualifiedName__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getQualifiedNameAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleQualifiedName"


    // $ANTLR start "entryRuleImport"
    // InternalStateMachineDsl.g:178:1: entryRuleImport : ruleImport EOF ;
    public final void entryRuleImport() throws RecognitionException {
        try {
            // InternalStateMachineDsl.g:179:1: ( ruleImport EOF )
            // InternalStateMachineDsl.g:180:1: ruleImport EOF
            {
             before(grammarAccess.getImportRule()); 
            pushFollow(FOLLOW_1);
            ruleImport();

            state._fsp--;

             after(grammarAccess.getImportRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleImport"


    // $ANTLR start "ruleImport"
    // InternalStateMachineDsl.g:187:1: ruleImport : ( ( rule__Import__Group__0 ) ) ;
    public final void ruleImport() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalStateMachineDsl.g:191:2: ( ( ( rule__Import__Group__0 ) ) )
            // InternalStateMachineDsl.g:192:2: ( ( rule__Import__Group__0 ) )
            {
            // InternalStateMachineDsl.g:192:2: ( ( rule__Import__Group__0 ) )
            // InternalStateMachineDsl.g:193:3: ( rule__Import__Group__0 )
            {
             before(grammarAccess.getImportAccess().getGroup()); 
            // InternalStateMachineDsl.g:194:3: ( rule__Import__Group__0 )
            // InternalStateMachineDsl.g:194:4: rule__Import__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Import__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getImportAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleImport"


    // $ANTLR start "entryRuleQualifiedNameWithWildcard"
    // InternalStateMachineDsl.g:203:1: entryRuleQualifiedNameWithWildcard : ruleQualifiedNameWithWildcard EOF ;
    public final void entryRuleQualifiedNameWithWildcard() throws RecognitionException {
        try {
            // InternalStateMachineDsl.g:204:1: ( ruleQualifiedNameWithWildcard EOF )
            // InternalStateMachineDsl.g:205:1: ruleQualifiedNameWithWildcard EOF
            {
             before(grammarAccess.getQualifiedNameWithWildcardRule()); 
            pushFollow(FOLLOW_1);
            ruleQualifiedNameWithWildcard();

            state._fsp--;

             after(grammarAccess.getQualifiedNameWithWildcardRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleQualifiedNameWithWildcard"


    // $ANTLR start "ruleQualifiedNameWithWildcard"
    // InternalStateMachineDsl.g:212:1: ruleQualifiedNameWithWildcard : ( ( rule__QualifiedNameWithWildcard__Group__0 ) ) ;
    public final void ruleQualifiedNameWithWildcard() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalStateMachineDsl.g:216:2: ( ( ( rule__QualifiedNameWithWildcard__Group__0 ) ) )
            // InternalStateMachineDsl.g:217:2: ( ( rule__QualifiedNameWithWildcard__Group__0 ) )
            {
            // InternalStateMachineDsl.g:217:2: ( ( rule__QualifiedNameWithWildcard__Group__0 ) )
            // InternalStateMachineDsl.g:218:3: ( rule__QualifiedNameWithWildcard__Group__0 )
            {
             before(grammarAccess.getQualifiedNameWithWildcardAccess().getGroup()); 
            // InternalStateMachineDsl.g:219:3: ( rule__QualifiedNameWithWildcard__Group__0 )
            // InternalStateMachineDsl.g:219:4: rule__QualifiedNameWithWildcard__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__QualifiedNameWithWildcard__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getQualifiedNameWithWildcardAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleQualifiedNameWithWildcard"


    // $ANTLR start "entryRuleLabel"
    // InternalStateMachineDsl.g:228:1: entryRuleLabel : ruleLabel EOF ;
    public final void entryRuleLabel() throws RecognitionException {
        try {
            // InternalStateMachineDsl.g:229:1: ( ruleLabel EOF )
            // InternalStateMachineDsl.g:230:1: ruleLabel EOF
            {
             before(grammarAccess.getLabelRule()); 
            pushFollow(FOLLOW_1);
            ruleLabel();

            state._fsp--;

             after(grammarAccess.getLabelRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleLabel"


    // $ANTLR start "ruleLabel"
    // InternalStateMachineDsl.g:237:1: ruleLabel : ( ( rule__Label__Alternatives ) ) ;
    public final void ruleLabel() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalStateMachineDsl.g:241:2: ( ( ( rule__Label__Alternatives ) ) )
            // InternalStateMachineDsl.g:242:2: ( ( rule__Label__Alternatives ) )
            {
            // InternalStateMachineDsl.g:242:2: ( ( rule__Label__Alternatives ) )
            // InternalStateMachineDsl.g:243:3: ( rule__Label__Alternatives )
            {
             before(grammarAccess.getLabelAccess().getAlternatives()); 
            // InternalStateMachineDsl.g:244:3: ( rule__Label__Alternatives )
            // InternalStateMachineDsl.g:244:4: rule__Label__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__Label__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getLabelAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleLabel"


    // $ANTLR start "entryRuleSingleLabel"
    // InternalStateMachineDsl.g:253:1: entryRuleSingleLabel : ruleSingleLabel EOF ;
    public final void entryRuleSingleLabel() throws RecognitionException {
        try {
            // InternalStateMachineDsl.g:254:1: ( ruleSingleLabel EOF )
            // InternalStateMachineDsl.g:255:1: ruleSingleLabel EOF
            {
             before(grammarAccess.getSingleLabelRule()); 
            pushFollow(FOLLOW_1);
            ruleSingleLabel();

            state._fsp--;

             after(grammarAccess.getSingleLabelRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleSingleLabel"


    // $ANTLR start "ruleSingleLabel"
    // InternalStateMachineDsl.g:262:1: ruleSingleLabel : ( ( rule__SingleLabel__Group__0 ) ) ;
    public final void ruleSingleLabel() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalStateMachineDsl.g:266:2: ( ( ( rule__SingleLabel__Group__0 ) ) )
            // InternalStateMachineDsl.g:267:2: ( ( rule__SingleLabel__Group__0 ) )
            {
            // InternalStateMachineDsl.g:267:2: ( ( rule__SingleLabel__Group__0 ) )
            // InternalStateMachineDsl.g:268:3: ( rule__SingleLabel__Group__0 )
            {
             before(grammarAccess.getSingleLabelAccess().getGroup()); 
            // InternalStateMachineDsl.g:269:3: ( rule__SingleLabel__Group__0 )
            // InternalStateMachineDsl.g:269:4: rule__SingleLabel__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__SingleLabel__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getSingleLabelAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleSingleLabel"


    // $ANTLR start "entryRuleListOfLabels"
    // InternalStateMachineDsl.g:278:1: entryRuleListOfLabels : ruleListOfLabels EOF ;
    public final void entryRuleListOfLabels() throws RecognitionException {
        try {
            // InternalStateMachineDsl.g:279:1: ( ruleListOfLabels EOF )
            // InternalStateMachineDsl.g:280:1: ruleListOfLabels EOF
            {
             before(grammarAccess.getListOfLabelsRule()); 
            pushFollow(FOLLOW_1);
            ruleListOfLabels();

            state._fsp--;

             after(grammarAccess.getListOfLabelsRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleListOfLabels"


    // $ANTLR start "ruleListOfLabels"
    // InternalStateMachineDsl.g:287:1: ruleListOfLabels : ( ( rule__ListOfLabels__Group__0 ) ) ;
    public final void ruleListOfLabels() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalStateMachineDsl.g:291:2: ( ( ( rule__ListOfLabels__Group__0 ) ) )
            // InternalStateMachineDsl.g:292:2: ( ( rule__ListOfLabels__Group__0 ) )
            {
            // InternalStateMachineDsl.g:292:2: ( ( rule__ListOfLabels__Group__0 ) )
            // InternalStateMachineDsl.g:293:3: ( rule__ListOfLabels__Group__0 )
            {
             before(grammarAccess.getListOfLabelsAccess().getGroup()); 
            // InternalStateMachineDsl.g:294:3: ( rule__ListOfLabels__Group__0 )
            // InternalStateMachineDsl.g:294:4: rule__ListOfLabels__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__ListOfLabels__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getListOfLabelsAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleListOfLabels"


    // $ANTLR start "entryRuleLabelName"
    // InternalStateMachineDsl.g:303:1: entryRuleLabelName : ruleLabelName EOF ;
    public final void entryRuleLabelName() throws RecognitionException {
        try {
            // InternalStateMachineDsl.g:304:1: ( ruleLabelName EOF )
            // InternalStateMachineDsl.g:305:1: ruleLabelName EOF
            {
             before(grammarAccess.getLabelNameRule()); 
            pushFollow(FOLLOW_1);
            ruleLabelName();

            state._fsp--;

             after(grammarAccess.getLabelNameRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleLabelName"


    // $ANTLR start "ruleLabelName"
    // InternalStateMachineDsl.g:312:1: ruleLabelName : ( ( rule__LabelName__NameAssignment ) ) ;
    public final void ruleLabelName() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalStateMachineDsl.g:316:2: ( ( ( rule__LabelName__NameAssignment ) ) )
            // InternalStateMachineDsl.g:317:2: ( ( rule__LabelName__NameAssignment ) )
            {
            // InternalStateMachineDsl.g:317:2: ( ( rule__LabelName__NameAssignment ) )
            // InternalStateMachineDsl.g:318:3: ( rule__LabelName__NameAssignment )
            {
             before(grammarAccess.getLabelNameAccess().getNameAssignment()); 
            // InternalStateMachineDsl.g:319:3: ( rule__LabelName__NameAssignment )
            // InternalStateMachineDsl.g:319:4: rule__LabelName__NameAssignment
            {
            pushFollow(FOLLOW_2);
            rule__LabelName__NameAssignment();

            state._fsp--;


            }

             after(grammarAccess.getLabelNameAccess().getNameAssignment()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleLabelName"


    // $ANTLR start "entryRuleNode"
    // InternalStateMachineDsl.g:328:1: entryRuleNode : ruleNode EOF ;
    public final void entryRuleNode() throws RecognitionException {
        try {
            // InternalStateMachineDsl.g:329:1: ( ruleNode EOF )
            // InternalStateMachineDsl.g:330:1: ruleNode EOF
            {
             before(grammarAccess.getNodeRule()); 
            pushFollow(FOLLOW_1);
            ruleNode();

            state._fsp--;

             after(grammarAccess.getNodeRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleNode"


    // $ANTLR start "ruleNode"
    // InternalStateMachineDsl.g:337:1: ruleNode : ( ( rule__Node__Alternatives ) ) ;
    public final void ruleNode() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalStateMachineDsl.g:341:2: ( ( ( rule__Node__Alternatives ) ) )
            // InternalStateMachineDsl.g:342:2: ( ( rule__Node__Alternatives ) )
            {
            // InternalStateMachineDsl.g:342:2: ( ( rule__Node__Alternatives ) )
            // InternalStateMachineDsl.g:343:3: ( rule__Node__Alternatives )
            {
             before(grammarAccess.getNodeAccess().getAlternatives()); 
            // InternalStateMachineDsl.g:344:3: ( rule__Node__Alternatives )
            // InternalStateMachineDsl.g:344:4: rule__Node__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__Node__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getNodeAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleNode"


    // $ANTLR start "entryRuleState"
    // InternalStateMachineDsl.g:353:1: entryRuleState : ruleState EOF ;
    public final void entryRuleState() throws RecognitionException {
        try {
            // InternalStateMachineDsl.g:354:1: ( ruleState EOF )
            // InternalStateMachineDsl.g:355:1: ruleState EOF
            {
             before(grammarAccess.getStateRule()); 
            pushFollow(FOLLOW_1);
            ruleState();

            state._fsp--;

             after(grammarAccess.getStateRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleState"


    // $ANTLR start "ruleState"
    // InternalStateMachineDsl.g:362:1: ruleState : ( ( rule__State__Group__0 ) ) ;
    public final void ruleState() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalStateMachineDsl.g:366:2: ( ( ( rule__State__Group__0 ) ) )
            // InternalStateMachineDsl.g:367:2: ( ( rule__State__Group__0 ) )
            {
            // InternalStateMachineDsl.g:367:2: ( ( rule__State__Group__0 ) )
            // InternalStateMachineDsl.g:368:3: ( rule__State__Group__0 )
            {
             before(grammarAccess.getStateAccess().getGroup()); 
            // InternalStateMachineDsl.g:369:3: ( rule__State__Group__0 )
            // InternalStateMachineDsl.g:369:4: rule__State__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__State__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getStateAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleState"


    // $ANTLR start "entryRuleTransition"
    // InternalStateMachineDsl.g:378:1: entryRuleTransition : ruleTransition EOF ;
    public final void entryRuleTransition() throws RecognitionException {
        try {
            // InternalStateMachineDsl.g:379:1: ( ruleTransition EOF )
            // InternalStateMachineDsl.g:380:1: ruleTransition EOF
            {
             before(grammarAccess.getTransitionRule()); 
            pushFollow(FOLLOW_1);
            ruleTransition();

            state._fsp--;

             after(grammarAccess.getTransitionRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleTransition"


    // $ANTLR start "ruleTransition"
    // InternalStateMachineDsl.g:387:1: ruleTransition : ( ( rule__Transition__Group__0 ) ) ;
    public final void ruleTransition() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalStateMachineDsl.g:391:2: ( ( ( rule__Transition__Group__0 ) ) )
            // InternalStateMachineDsl.g:392:2: ( ( rule__Transition__Group__0 ) )
            {
            // InternalStateMachineDsl.g:392:2: ( ( rule__Transition__Group__0 ) )
            // InternalStateMachineDsl.g:393:3: ( rule__Transition__Group__0 )
            {
             before(grammarAccess.getTransitionAccess().getGroup()); 
            // InternalStateMachineDsl.g:394:3: ( rule__Transition__Group__0 )
            // InternalStateMachineDsl.g:394:4: rule__Transition__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Transition__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getTransitionAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleTransition"


    // $ANTLR start "rule__AbstractElement__Alternatives"
    // InternalStateMachineDsl.g:402:1: rule__AbstractElement__Alternatives : ( ( ruleStateMachineDeclaration ) | ( ruleLabel ) | ( ruleNode ) | ( ruleImport ) | ( ruleInput ) );
    public final void rule__AbstractElement__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalStateMachineDsl.g:406:1: ( ( ruleStateMachineDeclaration ) | ( ruleLabel ) | ( ruleNode ) | ( ruleImport ) | ( ruleInput ) )
            int alt2=5;
            switch ( input.LA(1) ) {
            case 12:
                {
                alt2=1;
                }
                break;
            case 18:
            case 19:
                {
                alt2=2;
                }
                break;
            case 20:
            case 21:
                {
                alt2=3;
                }
                break;
            case 16:
                {
                alt2=4;
                }
                break;
            case 11:
                {
                alt2=5;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 2, 0, input);

                throw nvae;
            }

            switch (alt2) {
                case 1 :
                    // InternalStateMachineDsl.g:407:2: ( ruleStateMachineDeclaration )
                    {
                    // InternalStateMachineDsl.g:407:2: ( ruleStateMachineDeclaration )
                    // InternalStateMachineDsl.g:408:3: ruleStateMachineDeclaration
                    {
                     before(grammarAccess.getAbstractElementAccess().getStateMachineDeclarationParserRuleCall_0()); 
                    pushFollow(FOLLOW_2);
                    ruleStateMachineDeclaration();

                    state._fsp--;

                     after(grammarAccess.getAbstractElementAccess().getStateMachineDeclarationParserRuleCall_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalStateMachineDsl.g:413:2: ( ruleLabel )
                    {
                    // InternalStateMachineDsl.g:413:2: ( ruleLabel )
                    // InternalStateMachineDsl.g:414:3: ruleLabel
                    {
                     before(grammarAccess.getAbstractElementAccess().getLabelParserRuleCall_1()); 
                    pushFollow(FOLLOW_2);
                    ruleLabel();

                    state._fsp--;

                     after(grammarAccess.getAbstractElementAccess().getLabelParserRuleCall_1()); 

                    }


                    }
                    break;
                case 3 :
                    // InternalStateMachineDsl.g:419:2: ( ruleNode )
                    {
                    // InternalStateMachineDsl.g:419:2: ( ruleNode )
                    // InternalStateMachineDsl.g:420:3: ruleNode
                    {
                     before(grammarAccess.getAbstractElementAccess().getNodeParserRuleCall_2()); 
                    pushFollow(FOLLOW_2);
                    ruleNode();

                    state._fsp--;

                     after(grammarAccess.getAbstractElementAccess().getNodeParserRuleCall_2()); 

                    }


                    }
                    break;
                case 4 :
                    // InternalStateMachineDsl.g:425:2: ( ruleImport )
                    {
                    // InternalStateMachineDsl.g:425:2: ( ruleImport )
                    // InternalStateMachineDsl.g:426:3: ruleImport
                    {
                     before(grammarAccess.getAbstractElementAccess().getImportParserRuleCall_3()); 
                    pushFollow(FOLLOW_2);
                    ruleImport();

                    state._fsp--;

                     after(grammarAccess.getAbstractElementAccess().getImportParserRuleCall_3()); 

                    }


                    }
                    break;
                case 5 :
                    // InternalStateMachineDsl.g:431:2: ( ruleInput )
                    {
                    // InternalStateMachineDsl.g:431:2: ( ruleInput )
                    // InternalStateMachineDsl.g:432:3: ruleInput
                    {
                     before(grammarAccess.getAbstractElementAccess().getInputParserRuleCall_4()); 
                    pushFollow(FOLLOW_2);
                    ruleInput();

                    state._fsp--;

                     after(grammarAccess.getAbstractElementAccess().getInputParserRuleCall_4()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__AbstractElement__Alternatives"


    // $ANTLR start "rule__Label__Alternatives"
    // InternalStateMachineDsl.g:441:1: rule__Label__Alternatives : ( ( ruleSingleLabel ) | ( ruleListOfLabels ) );
    public final void rule__Label__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalStateMachineDsl.g:445:1: ( ( ruleSingleLabel ) | ( ruleListOfLabels ) )
            int alt3=2;
            int LA3_0 = input.LA(1);

            if ( (LA3_0==18) ) {
                alt3=1;
            }
            else if ( (LA3_0==19) ) {
                alt3=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 3, 0, input);

                throw nvae;
            }
            switch (alt3) {
                case 1 :
                    // InternalStateMachineDsl.g:446:2: ( ruleSingleLabel )
                    {
                    // InternalStateMachineDsl.g:446:2: ( ruleSingleLabel )
                    // InternalStateMachineDsl.g:447:3: ruleSingleLabel
                    {
                     before(grammarAccess.getLabelAccess().getSingleLabelParserRuleCall_0()); 
                    pushFollow(FOLLOW_2);
                    ruleSingleLabel();

                    state._fsp--;

                     after(grammarAccess.getLabelAccess().getSingleLabelParserRuleCall_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalStateMachineDsl.g:452:2: ( ruleListOfLabels )
                    {
                    // InternalStateMachineDsl.g:452:2: ( ruleListOfLabels )
                    // InternalStateMachineDsl.g:453:3: ruleListOfLabels
                    {
                     before(grammarAccess.getLabelAccess().getListOfLabelsParserRuleCall_1()); 
                    pushFollow(FOLLOW_2);
                    ruleListOfLabels();

                    state._fsp--;

                     after(grammarAccess.getLabelAccess().getListOfLabelsParserRuleCall_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Label__Alternatives"


    // $ANTLR start "rule__Node__Alternatives"
    // InternalStateMachineDsl.g:462:1: rule__Node__Alternatives : ( ( ruleState ) | ( ruleTransition ) );
    public final void rule__Node__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalStateMachineDsl.g:466:1: ( ( ruleState ) | ( ruleTransition ) )
            int alt4=2;
            int LA4_0 = input.LA(1);

            if ( (LA4_0==20) ) {
                alt4=1;
            }
            else if ( (LA4_0==21) ) {
                alt4=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 4, 0, input);

                throw nvae;
            }
            switch (alt4) {
                case 1 :
                    // InternalStateMachineDsl.g:467:2: ( ruleState )
                    {
                    // InternalStateMachineDsl.g:467:2: ( ruleState )
                    // InternalStateMachineDsl.g:468:3: ruleState
                    {
                     before(grammarAccess.getNodeAccess().getStateParserRuleCall_0()); 
                    pushFollow(FOLLOW_2);
                    ruleState();

                    state._fsp--;

                     after(grammarAccess.getNodeAccess().getStateParserRuleCall_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalStateMachineDsl.g:473:2: ( ruleTransition )
                    {
                    // InternalStateMachineDsl.g:473:2: ( ruleTransition )
                    // InternalStateMachineDsl.g:474:3: ruleTransition
                    {
                     before(grammarAccess.getNodeAccess().getTransitionParserRuleCall_1()); 
                    pushFollow(FOLLOW_2);
                    ruleTransition();

                    state._fsp--;

                     after(grammarAccess.getNodeAccess().getTransitionParserRuleCall_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Node__Alternatives"


    // $ANTLR start "rule__State__Alternatives_4"
    // InternalStateMachineDsl.g:483:1: rule__State__Alternatives_4 : ( ( ( rule__State__IsFinalAssignment_4_0 )? ) | ( ( rule__State__IsInitialAssignment_4_1 )? ) );
    public final void rule__State__Alternatives_4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalStateMachineDsl.g:487:1: ( ( ( rule__State__IsFinalAssignment_4_0 )? ) | ( ( rule__State__IsInitialAssignment_4_1 )? ) )
            int alt7=2;
            switch ( input.LA(1) ) {
            case 25:
                {
                alt7=1;
                }
                break;
            case 14:
                {
                alt7=1;
                }
                break;
            case 26:
                {
                alt7=2;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 7, 0, input);

                throw nvae;
            }

            switch (alt7) {
                case 1 :
                    // InternalStateMachineDsl.g:488:2: ( ( rule__State__IsFinalAssignment_4_0 )? )
                    {
                    // InternalStateMachineDsl.g:488:2: ( ( rule__State__IsFinalAssignment_4_0 )? )
                    // InternalStateMachineDsl.g:489:3: ( rule__State__IsFinalAssignment_4_0 )?
                    {
                     before(grammarAccess.getStateAccess().getIsFinalAssignment_4_0()); 
                    // InternalStateMachineDsl.g:490:3: ( rule__State__IsFinalAssignment_4_0 )?
                    int alt5=2;
                    int LA5_0 = input.LA(1);

                    if ( (LA5_0==25) ) {
                        alt5=1;
                    }
                    switch (alt5) {
                        case 1 :
                            // InternalStateMachineDsl.g:490:4: rule__State__IsFinalAssignment_4_0
                            {
                            pushFollow(FOLLOW_2);
                            rule__State__IsFinalAssignment_4_0();

                            state._fsp--;


                            }
                            break;

                    }

                     after(grammarAccess.getStateAccess().getIsFinalAssignment_4_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalStateMachineDsl.g:494:2: ( ( rule__State__IsInitialAssignment_4_1 )? )
                    {
                    // InternalStateMachineDsl.g:494:2: ( ( rule__State__IsInitialAssignment_4_1 )? )
                    // InternalStateMachineDsl.g:495:3: ( rule__State__IsInitialAssignment_4_1 )?
                    {
                     before(grammarAccess.getStateAccess().getIsInitialAssignment_4_1()); 
                    // InternalStateMachineDsl.g:496:3: ( rule__State__IsInitialAssignment_4_1 )?
                    int alt6=2;
                    int LA6_0 = input.LA(1);

                    if ( (LA6_0==26) ) {
                        alt6=1;
                    }
                    switch (alt6) {
                        case 1 :
                            // InternalStateMachineDsl.g:496:4: rule__State__IsInitialAssignment_4_1
                            {
                            pushFollow(FOLLOW_2);
                            rule__State__IsInitialAssignment_4_1();

                            state._fsp--;


                            }
                            break;

                    }

                     after(grammarAccess.getStateAccess().getIsInitialAssignment_4_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__State__Alternatives_4"


    // $ANTLR start "rule__Input__Group__0"
    // InternalStateMachineDsl.g:504:1: rule__Input__Group__0 : rule__Input__Group__0__Impl rule__Input__Group__1 ;
    public final void rule__Input__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalStateMachineDsl.g:508:1: ( rule__Input__Group__0__Impl rule__Input__Group__1 )
            // InternalStateMachineDsl.g:509:2: rule__Input__Group__0__Impl rule__Input__Group__1
            {
            pushFollow(FOLLOW_4);
            rule__Input__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Input__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Input__Group__0"


    // $ANTLR start "rule__Input__Group__0__Impl"
    // InternalStateMachineDsl.g:516:1: rule__Input__Group__0__Impl : ( 'word' ) ;
    public final void rule__Input__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalStateMachineDsl.g:520:1: ( ( 'word' ) )
            // InternalStateMachineDsl.g:521:1: ( 'word' )
            {
            // InternalStateMachineDsl.g:521:1: ( 'word' )
            // InternalStateMachineDsl.g:522:2: 'word'
            {
             before(grammarAccess.getInputAccess().getWordKeyword_0()); 
            match(input,11,FOLLOW_2); 
             after(grammarAccess.getInputAccess().getWordKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Input__Group__0__Impl"


    // $ANTLR start "rule__Input__Group__1"
    // InternalStateMachineDsl.g:531:1: rule__Input__Group__1 : rule__Input__Group__1__Impl ;
    public final void rule__Input__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalStateMachineDsl.g:535:1: ( rule__Input__Group__1__Impl )
            // InternalStateMachineDsl.g:536:2: rule__Input__Group__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Input__Group__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Input__Group__1"


    // $ANTLR start "rule__Input__Group__1__Impl"
    // InternalStateMachineDsl.g:542:1: rule__Input__Group__1__Impl : ( ( rule__Input__ValueAssignment_1 ) ) ;
    public final void rule__Input__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalStateMachineDsl.g:546:1: ( ( ( rule__Input__ValueAssignment_1 ) ) )
            // InternalStateMachineDsl.g:547:1: ( ( rule__Input__ValueAssignment_1 ) )
            {
            // InternalStateMachineDsl.g:547:1: ( ( rule__Input__ValueAssignment_1 ) )
            // InternalStateMachineDsl.g:548:2: ( rule__Input__ValueAssignment_1 )
            {
             before(grammarAccess.getInputAccess().getValueAssignment_1()); 
            // InternalStateMachineDsl.g:549:2: ( rule__Input__ValueAssignment_1 )
            // InternalStateMachineDsl.g:549:3: rule__Input__ValueAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__Input__ValueAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getInputAccess().getValueAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Input__Group__1__Impl"


    // $ANTLR start "rule__StateMachineDeclaration__Group__0"
    // InternalStateMachineDsl.g:558:1: rule__StateMachineDeclaration__Group__0 : rule__StateMachineDeclaration__Group__0__Impl rule__StateMachineDeclaration__Group__1 ;
    public final void rule__StateMachineDeclaration__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalStateMachineDsl.g:562:1: ( rule__StateMachineDeclaration__Group__0__Impl rule__StateMachineDeclaration__Group__1 )
            // InternalStateMachineDsl.g:563:2: rule__StateMachineDeclaration__Group__0__Impl rule__StateMachineDeclaration__Group__1
            {
            pushFollow(FOLLOW_4);
            rule__StateMachineDeclaration__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__StateMachineDeclaration__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachineDeclaration__Group__0"


    // $ANTLR start "rule__StateMachineDeclaration__Group__0__Impl"
    // InternalStateMachineDsl.g:570:1: rule__StateMachineDeclaration__Group__0__Impl : ( 'automaton' ) ;
    public final void rule__StateMachineDeclaration__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalStateMachineDsl.g:574:1: ( ( 'automaton' ) )
            // InternalStateMachineDsl.g:575:1: ( 'automaton' )
            {
            // InternalStateMachineDsl.g:575:1: ( 'automaton' )
            // InternalStateMachineDsl.g:576:2: 'automaton'
            {
             before(grammarAccess.getStateMachineDeclarationAccess().getAutomatonKeyword_0()); 
            match(input,12,FOLLOW_2); 
             after(grammarAccess.getStateMachineDeclarationAccess().getAutomatonKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachineDeclaration__Group__0__Impl"


    // $ANTLR start "rule__StateMachineDeclaration__Group__1"
    // InternalStateMachineDsl.g:585:1: rule__StateMachineDeclaration__Group__1 : rule__StateMachineDeclaration__Group__1__Impl rule__StateMachineDeclaration__Group__2 ;
    public final void rule__StateMachineDeclaration__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalStateMachineDsl.g:589:1: ( rule__StateMachineDeclaration__Group__1__Impl rule__StateMachineDeclaration__Group__2 )
            // InternalStateMachineDsl.g:590:2: rule__StateMachineDeclaration__Group__1__Impl rule__StateMachineDeclaration__Group__2
            {
            pushFollow(FOLLOW_5);
            rule__StateMachineDeclaration__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__StateMachineDeclaration__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachineDeclaration__Group__1"


    // $ANTLR start "rule__StateMachineDeclaration__Group__1__Impl"
    // InternalStateMachineDsl.g:597:1: rule__StateMachineDeclaration__Group__1__Impl : ( ( rule__StateMachineDeclaration__NameAssignment_1 ) ) ;
    public final void rule__StateMachineDeclaration__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalStateMachineDsl.g:601:1: ( ( ( rule__StateMachineDeclaration__NameAssignment_1 ) ) )
            // InternalStateMachineDsl.g:602:1: ( ( rule__StateMachineDeclaration__NameAssignment_1 ) )
            {
            // InternalStateMachineDsl.g:602:1: ( ( rule__StateMachineDeclaration__NameAssignment_1 ) )
            // InternalStateMachineDsl.g:603:2: ( rule__StateMachineDeclaration__NameAssignment_1 )
            {
             before(grammarAccess.getStateMachineDeclarationAccess().getNameAssignment_1()); 
            // InternalStateMachineDsl.g:604:2: ( rule__StateMachineDeclaration__NameAssignment_1 )
            // InternalStateMachineDsl.g:604:3: rule__StateMachineDeclaration__NameAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__StateMachineDeclaration__NameAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getStateMachineDeclarationAccess().getNameAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachineDeclaration__Group__1__Impl"


    // $ANTLR start "rule__StateMachineDeclaration__Group__2"
    // InternalStateMachineDsl.g:612:1: rule__StateMachineDeclaration__Group__2 : rule__StateMachineDeclaration__Group__2__Impl rule__StateMachineDeclaration__Group__3 ;
    public final void rule__StateMachineDeclaration__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalStateMachineDsl.g:616:1: ( rule__StateMachineDeclaration__Group__2__Impl rule__StateMachineDeclaration__Group__3 )
            // InternalStateMachineDsl.g:617:2: rule__StateMachineDeclaration__Group__2__Impl rule__StateMachineDeclaration__Group__3
            {
            pushFollow(FOLLOW_6);
            rule__StateMachineDeclaration__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__StateMachineDeclaration__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachineDeclaration__Group__2"


    // $ANTLR start "rule__StateMachineDeclaration__Group__2__Impl"
    // InternalStateMachineDsl.g:624:1: rule__StateMachineDeclaration__Group__2__Impl : ( '{' ) ;
    public final void rule__StateMachineDeclaration__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalStateMachineDsl.g:628:1: ( ( '{' ) )
            // InternalStateMachineDsl.g:629:1: ( '{' )
            {
            // InternalStateMachineDsl.g:629:1: ( '{' )
            // InternalStateMachineDsl.g:630:2: '{'
            {
             before(grammarAccess.getStateMachineDeclarationAccess().getLeftCurlyBracketKeyword_2()); 
            match(input,13,FOLLOW_2); 
             after(grammarAccess.getStateMachineDeclarationAccess().getLeftCurlyBracketKeyword_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachineDeclaration__Group__2__Impl"


    // $ANTLR start "rule__StateMachineDeclaration__Group__3"
    // InternalStateMachineDsl.g:639:1: rule__StateMachineDeclaration__Group__3 : rule__StateMachineDeclaration__Group__3__Impl rule__StateMachineDeclaration__Group__4 ;
    public final void rule__StateMachineDeclaration__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalStateMachineDsl.g:643:1: ( rule__StateMachineDeclaration__Group__3__Impl rule__StateMachineDeclaration__Group__4 )
            // InternalStateMachineDsl.g:644:2: rule__StateMachineDeclaration__Group__3__Impl rule__StateMachineDeclaration__Group__4
            {
            pushFollow(FOLLOW_6);
            rule__StateMachineDeclaration__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__StateMachineDeclaration__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachineDeclaration__Group__3"


    // $ANTLR start "rule__StateMachineDeclaration__Group__3__Impl"
    // InternalStateMachineDsl.g:651:1: rule__StateMachineDeclaration__Group__3__Impl : ( ( rule__StateMachineDeclaration__ElementsAssignment_3 )* ) ;
    public final void rule__StateMachineDeclaration__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalStateMachineDsl.g:655:1: ( ( ( rule__StateMachineDeclaration__ElementsAssignment_3 )* ) )
            // InternalStateMachineDsl.g:656:1: ( ( rule__StateMachineDeclaration__ElementsAssignment_3 )* )
            {
            // InternalStateMachineDsl.g:656:1: ( ( rule__StateMachineDeclaration__ElementsAssignment_3 )* )
            // InternalStateMachineDsl.g:657:2: ( rule__StateMachineDeclaration__ElementsAssignment_3 )*
            {
             before(grammarAccess.getStateMachineDeclarationAccess().getElementsAssignment_3()); 
            // InternalStateMachineDsl.g:658:2: ( rule__StateMachineDeclaration__ElementsAssignment_3 )*
            loop8:
            do {
                int alt8=2;
                int LA8_0 = input.LA(1);

                if ( ((LA8_0>=11 && LA8_0<=12)||LA8_0==16||(LA8_0>=18 && LA8_0<=21)) ) {
                    alt8=1;
                }


                switch (alt8) {
            	case 1 :
            	    // InternalStateMachineDsl.g:658:3: rule__StateMachineDeclaration__ElementsAssignment_3
            	    {
            	    pushFollow(FOLLOW_3);
            	    rule__StateMachineDeclaration__ElementsAssignment_3();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop8;
                }
            } while (true);

             after(grammarAccess.getStateMachineDeclarationAccess().getElementsAssignment_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachineDeclaration__Group__3__Impl"


    // $ANTLR start "rule__StateMachineDeclaration__Group__4"
    // InternalStateMachineDsl.g:666:1: rule__StateMachineDeclaration__Group__4 : rule__StateMachineDeclaration__Group__4__Impl ;
    public final void rule__StateMachineDeclaration__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalStateMachineDsl.g:670:1: ( rule__StateMachineDeclaration__Group__4__Impl )
            // InternalStateMachineDsl.g:671:2: rule__StateMachineDeclaration__Group__4__Impl
            {
            pushFollow(FOLLOW_2);
            rule__StateMachineDeclaration__Group__4__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachineDeclaration__Group__4"


    // $ANTLR start "rule__StateMachineDeclaration__Group__4__Impl"
    // InternalStateMachineDsl.g:677:1: rule__StateMachineDeclaration__Group__4__Impl : ( '}' ) ;
    public final void rule__StateMachineDeclaration__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalStateMachineDsl.g:681:1: ( ( '}' ) )
            // InternalStateMachineDsl.g:682:1: ( '}' )
            {
            // InternalStateMachineDsl.g:682:1: ( '}' )
            // InternalStateMachineDsl.g:683:2: '}'
            {
             before(grammarAccess.getStateMachineDeclarationAccess().getRightCurlyBracketKeyword_4()); 
            match(input,14,FOLLOW_2); 
             after(grammarAccess.getStateMachineDeclarationAccess().getRightCurlyBracketKeyword_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachineDeclaration__Group__4__Impl"


    // $ANTLR start "rule__QualifiedName__Group__0"
    // InternalStateMachineDsl.g:693:1: rule__QualifiedName__Group__0 : rule__QualifiedName__Group__0__Impl rule__QualifiedName__Group__1 ;
    public final void rule__QualifiedName__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalStateMachineDsl.g:697:1: ( rule__QualifiedName__Group__0__Impl rule__QualifiedName__Group__1 )
            // InternalStateMachineDsl.g:698:2: rule__QualifiedName__Group__0__Impl rule__QualifiedName__Group__1
            {
            pushFollow(FOLLOW_7);
            rule__QualifiedName__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__QualifiedName__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualifiedName__Group__0"


    // $ANTLR start "rule__QualifiedName__Group__0__Impl"
    // InternalStateMachineDsl.g:705:1: rule__QualifiedName__Group__0__Impl : ( RULE_ID ) ;
    public final void rule__QualifiedName__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalStateMachineDsl.g:709:1: ( ( RULE_ID ) )
            // InternalStateMachineDsl.g:710:1: ( RULE_ID )
            {
            // InternalStateMachineDsl.g:710:1: ( RULE_ID )
            // InternalStateMachineDsl.g:711:2: RULE_ID
            {
             before(grammarAccess.getQualifiedNameAccess().getIDTerminalRuleCall_0()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getQualifiedNameAccess().getIDTerminalRuleCall_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualifiedName__Group__0__Impl"


    // $ANTLR start "rule__QualifiedName__Group__1"
    // InternalStateMachineDsl.g:720:1: rule__QualifiedName__Group__1 : rule__QualifiedName__Group__1__Impl ;
    public final void rule__QualifiedName__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalStateMachineDsl.g:724:1: ( rule__QualifiedName__Group__1__Impl )
            // InternalStateMachineDsl.g:725:2: rule__QualifiedName__Group__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__QualifiedName__Group__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualifiedName__Group__1"


    // $ANTLR start "rule__QualifiedName__Group__1__Impl"
    // InternalStateMachineDsl.g:731:1: rule__QualifiedName__Group__1__Impl : ( ( rule__QualifiedName__Group_1__0 )* ) ;
    public final void rule__QualifiedName__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalStateMachineDsl.g:735:1: ( ( ( rule__QualifiedName__Group_1__0 )* ) )
            // InternalStateMachineDsl.g:736:1: ( ( rule__QualifiedName__Group_1__0 )* )
            {
            // InternalStateMachineDsl.g:736:1: ( ( rule__QualifiedName__Group_1__0 )* )
            // InternalStateMachineDsl.g:737:2: ( rule__QualifiedName__Group_1__0 )*
            {
             before(grammarAccess.getQualifiedNameAccess().getGroup_1()); 
            // InternalStateMachineDsl.g:738:2: ( rule__QualifiedName__Group_1__0 )*
            loop9:
            do {
                int alt9=2;
                int LA9_0 = input.LA(1);

                if ( (LA9_0==15) ) {
                    alt9=1;
                }


                switch (alt9) {
            	case 1 :
            	    // InternalStateMachineDsl.g:738:3: rule__QualifiedName__Group_1__0
            	    {
            	    pushFollow(FOLLOW_8);
            	    rule__QualifiedName__Group_1__0();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop9;
                }
            } while (true);

             after(grammarAccess.getQualifiedNameAccess().getGroup_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualifiedName__Group__1__Impl"


    // $ANTLR start "rule__QualifiedName__Group_1__0"
    // InternalStateMachineDsl.g:747:1: rule__QualifiedName__Group_1__0 : rule__QualifiedName__Group_1__0__Impl rule__QualifiedName__Group_1__1 ;
    public final void rule__QualifiedName__Group_1__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalStateMachineDsl.g:751:1: ( rule__QualifiedName__Group_1__0__Impl rule__QualifiedName__Group_1__1 )
            // InternalStateMachineDsl.g:752:2: rule__QualifiedName__Group_1__0__Impl rule__QualifiedName__Group_1__1
            {
            pushFollow(FOLLOW_4);
            rule__QualifiedName__Group_1__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__QualifiedName__Group_1__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualifiedName__Group_1__0"


    // $ANTLR start "rule__QualifiedName__Group_1__0__Impl"
    // InternalStateMachineDsl.g:759:1: rule__QualifiedName__Group_1__0__Impl : ( '.' ) ;
    public final void rule__QualifiedName__Group_1__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalStateMachineDsl.g:763:1: ( ( '.' ) )
            // InternalStateMachineDsl.g:764:1: ( '.' )
            {
            // InternalStateMachineDsl.g:764:1: ( '.' )
            // InternalStateMachineDsl.g:765:2: '.'
            {
             before(grammarAccess.getQualifiedNameAccess().getFullStopKeyword_1_0()); 
            match(input,15,FOLLOW_2); 
             after(grammarAccess.getQualifiedNameAccess().getFullStopKeyword_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualifiedName__Group_1__0__Impl"


    // $ANTLR start "rule__QualifiedName__Group_1__1"
    // InternalStateMachineDsl.g:774:1: rule__QualifiedName__Group_1__1 : rule__QualifiedName__Group_1__1__Impl ;
    public final void rule__QualifiedName__Group_1__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalStateMachineDsl.g:778:1: ( rule__QualifiedName__Group_1__1__Impl )
            // InternalStateMachineDsl.g:779:2: rule__QualifiedName__Group_1__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__QualifiedName__Group_1__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualifiedName__Group_1__1"


    // $ANTLR start "rule__QualifiedName__Group_1__1__Impl"
    // InternalStateMachineDsl.g:785:1: rule__QualifiedName__Group_1__1__Impl : ( RULE_ID ) ;
    public final void rule__QualifiedName__Group_1__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalStateMachineDsl.g:789:1: ( ( RULE_ID ) )
            // InternalStateMachineDsl.g:790:1: ( RULE_ID )
            {
            // InternalStateMachineDsl.g:790:1: ( RULE_ID )
            // InternalStateMachineDsl.g:791:2: RULE_ID
            {
             before(grammarAccess.getQualifiedNameAccess().getIDTerminalRuleCall_1_1()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getQualifiedNameAccess().getIDTerminalRuleCall_1_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualifiedName__Group_1__1__Impl"


    // $ANTLR start "rule__Import__Group__0"
    // InternalStateMachineDsl.g:801:1: rule__Import__Group__0 : rule__Import__Group__0__Impl rule__Import__Group__1 ;
    public final void rule__Import__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalStateMachineDsl.g:805:1: ( rule__Import__Group__0__Impl rule__Import__Group__1 )
            // InternalStateMachineDsl.g:806:2: rule__Import__Group__0__Impl rule__Import__Group__1
            {
            pushFollow(FOLLOW_4);
            rule__Import__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Import__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Import__Group__0"


    // $ANTLR start "rule__Import__Group__0__Impl"
    // InternalStateMachineDsl.g:813:1: rule__Import__Group__0__Impl : ( 'import' ) ;
    public final void rule__Import__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalStateMachineDsl.g:817:1: ( ( 'import' ) )
            // InternalStateMachineDsl.g:818:1: ( 'import' )
            {
            // InternalStateMachineDsl.g:818:1: ( 'import' )
            // InternalStateMachineDsl.g:819:2: 'import'
            {
             before(grammarAccess.getImportAccess().getImportKeyword_0()); 
            match(input,16,FOLLOW_2); 
             after(grammarAccess.getImportAccess().getImportKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Import__Group__0__Impl"


    // $ANTLR start "rule__Import__Group__1"
    // InternalStateMachineDsl.g:828:1: rule__Import__Group__1 : rule__Import__Group__1__Impl ;
    public final void rule__Import__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalStateMachineDsl.g:832:1: ( rule__Import__Group__1__Impl )
            // InternalStateMachineDsl.g:833:2: rule__Import__Group__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Import__Group__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Import__Group__1"


    // $ANTLR start "rule__Import__Group__1__Impl"
    // InternalStateMachineDsl.g:839:1: rule__Import__Group__1__Impl : ( ( rule__Import__ImportedNamespaceAssignment_1 ) ) ;
    public final void rule__Import__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalStateMachineDsl.g:843:1: ( ( ( rule__Import__ImportedNamespaceAssignment_1 ) ) )
            // InternalStateMachineDsl.g:844:1: ( ( rule__Import__ImportedNamespaceAssignment_1 ) )
            {
            // InternalStateMachineDsl.g:844:1: ( ( rule__Import__ImportedNamespaceAssignment_1 ) )
            // InternalStateMachineDsl.g:845:2: ( rule__Import__ImportedNamespaceAssignment_1 )
            {
             before(grammarAccess.getImportAccess().getImportedNamespaceAssignment_1()); 
            // InternalStateMachineDsl.g:846:2: ( rule__Import__ImportedNamespaceAssignment_1 )
            // InternalStateMachineDsl.g:846:3: rule__Import__ImportedNamespaceAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__Import__ImportedNamespaceAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getImportAccess().getImportedNamespaceAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Import__Group__1__Impl"


    // $ANTLR start "rule__QualifiedNameWithWildcard__Group__0"
    // InternalStateMachineDsl.g:855:1: rule__QualifiedNameWithWildcard__Group__0 : rule__QualifiedNameWithWildcard__Group__0__Impl rule__QualifiedNameWithWildcard__Group__1 ;
    public final void rule__QualifiedNameWithWildcard__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalStateMachineDsl.g:859:1: ( rule__QualifiedNameWithWildcard__Group__0__Impl rule__QualifiedNameWithWildcard__Group__1 )
            // InternalStateMachineDsl.g:860:2: rule__QualifiedNameWithWildcard__Group__0__Impl rule__QualifiedNameWithWildcard__Group__1
            {
            pushFollow(FOLLOW_9);
            rule__QualifiedNameWithWildcard__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__QualifiedNameWithWildcard__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualifiedNameWithWildcard__Group__0"


    // $ANTLR start "rule__QualifiedNameWithWildcard__Group__0__Impl"
    // InternalStateMachineDsl.g:867:1: rule__QualifiedNameWithWildcard__Group__0__Impl : ( ruleQualifiedName ) ;
    public final void rule__QualifiedNameWithWildcard__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalStateMachineDsl.g:871:1: ( ( ruleQualifiedName ) )
            // InternalStateMachineDsl.g:872:1: ( ruleQualifiedName )
            {
            // InternalStateMachineDsl.g:872:1: ( ruleQualifiedName )
            // InternalStateMachineDsl.g:873:2: ruleQualifiedName
            {
             before(grammarAccess.getQualifiedNameWithWildcardAccess().getQualifiedNameParserRuleCall_0()); 
            pushFollow(FOLLOW_2);
            ruleQualifiedName();

            state._fsp--;

             after(grammarAccess.getQualifiedNameWithWildcardAccess().getQualifiedNameParserRuleCall_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualifiedNameWithWildcard__Group__0__Impl"


    // $ANTLR start "rule__QualifiedNameWithWildcard__Group__1"
    // InternalStateMachineDsl.g:882:1: rule__QualifiedNameWithWildcard__Group__1 : rule__QualifiedNameWithWildcard__Group__1__Impl ;
    public final void rule__QualifiedNameWithWildcard__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalStateMachineDsl.g:886:1: ( rule__QualifiedNameWithWildcard__Group__1__Impl )
            // InternalStateMachineDsl.g:887:2: rule__QualifiedNameWithWildcard__Group__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__QualifiedNameWithWildcard__Group__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualifiedNameWithWildcard__Group__1"


    // $ANTLR start "rule__QualifiedNameWithWildcard__Group__1__Impl"
    // InternalStateMachineDsl.g:893:1: rule__QualifiedNameWithWildcard__Group__1__Impl : ( ( '.*' )? ) ;
    public final void rule__QualifiedNameWithWildcard__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalStateMachineDsl.g:897:1: ( ( ( '.*' )? ) )
            // InternalStateMachineDsl.g:898:1: ( ( '.*' )? )
            {
            // InternalStateMachineDsl.g:898:1: ( ( '.*' )? )
            // InternalStateMachineDsl.g:899:2: ( '.*' )?
            {
             before(grammarAccess.getQualifiedNameWithWildcardAccess().getFullStopAsteriskKeyword_1()); 
            // InternalStateMachineDsl.g:900:2: ( '.*' )?
            int alt10=2;
            int LA10_0 = input.LA(1);

            if ( (LA10_0==17) ) {
                alt10=1;
            }
            switch (alt10) {
                case 1 :
                    // InternalStateMachineDsl.g:900:3: '.*'
                    {
                    match(input,17,FOLLOW_2); 

                    }
                    break;

            }

             after(grammarAccess.getQualifiedNameWithWildcardAccess().getFullStopAsteriskKeyword_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualifiedNameWithWildcard__Group__1__Impl"


    // $ANTLR start "rule__SingleLabel__Group__0"
    // InternalStateMachineDsl.g:909:1: rule__SingleLabel__Group__0 : rule__SingleLabel__Group__0__Impl rule__SingleLabel__Group__1 ;
    public final void rule__SingleLabel__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalStateMachineDsl.g:913:1: ( rule__SingleLabel__Group__0__Impl rule__SingleLabel__Group__1 )
            // InternalStateMachineDsl.g:914:2: rule__SingleLabel__Group__0__Impl rule__SingleLabel__Group__1
            {
            pushFollow(FOLLOW_4);
            rule__SingleLabel__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__SingleLabel__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SingleLabel__Group__0"


    // $ANTLR start "rule__SingleLabel__Group__0__Impl"
    // InternalStateMachineDsl.g:921:1: rule__SingleLabel__Group__0__Impl : ( 'label' ) ;
    public final void rule__SingleLabel__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalStateMachineDsl.g:925:1: ( ( 'label' ) )
            // InternalStateMachineDsl.g:926:1: ( 'label' )
            {
            // InternalStateMachineDsl.g:926:1: ( 'label' )
            // InternalStateMachineDsl.g:927:2: 'label'
            {
             before(grammarAccess.getSingleLabelAccess().getLabelKeyword_0()); 
            match(input,18,FOLLOW_2); 
             after(grammarAccess.getSingleLabelAccess().getLabelKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SingleLabel__Group__0__Impl"


    // $ANTLR start "rule__SingleLabel__Group__1"
    // InternalStateMachineDsl.g:936:1: rule__SingleLabel__Group__1 : rule__SingleLabel__Group__1__Impl ;
    public final void rule__SingleLabel__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalStateMachineDsl.g:940:1: ( rule__SingleLabel__Group__1__Impl )
            // InternalStateMachineDsl.g:941:2: rule__SingleLabel__Group__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__SingleLabel__Group__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SingleLabel__Group__1"


    // $ANTLR start "rule__SingleLabel__Group__1__Impl"
    // InternalStateMachineDsl.g:947:1: rule__SingleLabel__Group__1__Impl : ( ( rule__SingleLabel__LabelAssignment_1 ) ) ;
    public final void rule__SingleLabel__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalStateMachineDsl.g:951:1: ( ( ( rule__SingleLabel__LabelAssignment_1 ) ) )
            // InternalStateMachineDsl.g:952:1: ( ( rule__SingleLabel__LabelAssignment_1 ) )
            {
            // InternalStateMachineDsl.g:952:1: ( ( rule__SingleLabel__LabelAssignment_1 ) )
            // InternalStateMachineDsl.g:953:2: ( rule__SingleLabel__LabelAssignment_1 )
            {
             before(grammarAccess.getSingleLabelAccess().getLabelAssignment_1()); 
            // InternalStateMachineDsl.g:954:2: ( rule__SingleLabel__LabelAssignment_1 )
            // InternalStateMachineDsl.g:954:3: rule__SingleLabel__LabelAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__SingleLabel__LabelAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getSingleLabelAccess().getLabelAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SingleLabel__Group__1__Impl"


    // $ANTLR start "rule__ListOfLabels__Group__0"
    // InternalStateMachineDsl.g:963:1: rule__ListOfLabels__Group__0 : rule__ListOfLabels__Group__0__Impl rule__ListOfLabels__Group__1 ;
    public final void rule__ListOfLabels__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalStateMachineDsl.g:967:1: ( rule__ListOfLabels__Group__0__Impl rule__ListOfLabels__Group__1 )
            // InternalStateMachineDsl.g:968:2: rule__ListOfLabels__Group__0__Impl rule__ListOfLabels__Group__1
            {
            pushFollow(FOLLOW_4);
            rule__ListOfLabels__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ListOfLabels__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ListOfLabels__Group__0"


    // $ANTLR start "rule__ListOfLabels__Group__0__Impl"
    // InternalStateMachineDsl.g:975:1: rule__ListOfLabels__Group__0__Impl : ( 'labels' ) ;
    public final void rule__ListOfLabels__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalStateMachineDsl.g:979:1: ( ( 'labels' ) )
            // InternalStateMachineDsl.g:980:1: ( 'labels' )
            {
            // InternalStateMachineDsl.g:980:1: ( 'labels' )
            // InternalStateMachineDsl.g:981:2: 'labels'
            {
             before(grammarAccess.getListOfLabelsAccess().getLabelsKeyword_0()); 
            match(input,19,FOLLOW_2); 
             after(grammarAccess.getListOfLabelsAccess().getLabelsKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ListOfLabels__Group__0__Impl"


    // $ANTLR start "rule__ListOfLabels__Group__1"
    // InternalStateMachineDsl.g:990:1: rule__ListOfLabels__Group__1 : rule__ListOfLabels__Group__1__Impl ;
    public final void rule__ListOfLabels__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalStateMachineDsl.g:994:1: ( rule__ListOfLabels__Group__1__Impl )
            // InternalStateMachineDsl.g:995:2: rule__ListOfLabels__Group__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__ListOfLabels__Group__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ListOfLabels__Group__1"


    // $ANTLR start "rule__ListOfLabels__Group__1__Impl"
    // InternalStateMachineDsl.g:1001:1: rule__ListOfLabels__Group__1__Impl : ( ( ( rule__ListOfLabels__LabelsAssignment_1 ) ) ( ( rule__ListOfLabels__LabelsAssignment_1 )* ) ) ;
    public final void rule__ListOfLabels__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalStateMachineDsl.g:1005:1: ( ( ( ( rule__ListOfLabels__LabelsAssignment_1 ) ) ( ( rule__ListOfLabels__LabelsAssignment_1 )* ) ) )
            // InternalStateMachineDsl.g:1006:1: ( ( ( rule__ListOfLabels__LabelsAssignment_1 ) ) ( ( rule__ListOfLabels__LabelsAssignment_1 )* ) )
            {
            // InternalStateMachineDsl.g:1006:1: ( ( ( rule__ListOfLabels__LabelsAssignment_1 ) ) ( ( rule__ListOfLabels__LabelsAssignment_1 )* ) )
            // InternalStateMachineDsl.g:1007:2: ( ( rule__ListOfLabels__LabelsAssignment_1 ) ) ( ( rule__ListOfLabels__LabelsAssignment_1 )* )
            {
            // InternalStateMachineDsl.g:1007:2: ( ( rule__ListOfLabels__LabelsAssignment_1 ) )
            // InternalStateMachineDsl.g:1008:3: ( rule__ListOfLabels__LabelsAssignment_1 )
            {
             before(grammarAccess.getListOfLabelsAccess().getLabelsAssignment_1()); 
            // InternalStateMachineDsl.g:1009:3: ( rule__ListOfLabels__LabelsAssignment_1 )
            // InternalStateMachineDsl.g:1009:4: rule__ListOfLabels__LabelsAssignment_1
            {
            pushFollow(FOLLOW_10);
            rule__ListOfLabels__LabelsAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getListOfLabelsAccess().getLabelsAssignment_1()); 

            }

            // InternalStateMachineDsl.g:1012:2: ( ( rule__ListOfLabels__LabelsAssignment_1 )* )
            // InternalStateMachineDsl.g:1013:3: ( rule__ListOfLabels__LabelsAssignment_1 )*
            {
             before(grammarAccess.getListOfLabelsAccess().getLabelsAssignment_1()); 
            // InternalStateMachineDsl.g:1014:3: ( rule__ListOfLabels__LabelsAssignment_1 )*
            loop11:
            do {
                int alt11=2;
                int LA11_0 = input.LA(1);

                if ( (LA11_0==RULE_ID) ) {
                    alt11=1;
                }


                switch (alt11) {
            	case 1 :
            	    // InternalStateMachineDsl.g:1014:4: rule__ListOfLabels__LabelsAssignment_1
            	    {
            	    pushFollow(FOLLOW_10);
            	    rule__ListOfLabels__LabelsAssignment_1();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop11;
                }
            } while (true);

             after(grammarAccess.getListOfLabelsAccess().getLabelsAssignment_1()); 

            }


            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ListOfLabels__Group__1__Impl"


    // $ANTLR start "rule__State__Group__0"
    // InternalStateMachineDsl.g:1024:1: rule__State__Group__0 : rule__State__Group__0__Impl rule__State__Group__1 ;
    public final void rule__State__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalStateMachineDsl.g:1028:1: ( rule__State__Group__0__Impl rule__State__Group__1 )
            // InternalStateMachineDsl.g:1029:2: rule__State__Group__0__Impl rule__State__Group__1
            {
            pushFollow(FOLLOW_11);
            rule__State__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__State__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__State__Group__0"


    // $ANTLR start "rule__State__Group__0__Impl"
    // InternalStateMachineDsl.g:1036:1: rule__State__Group__0__Impl : ( () ) ;
    public final void rule__State__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalStateMachineDsl.g:1040:1: ( ( () ) )
            // InternalStateMachineDsl.g:1041:1: ( () )
            {
            // InternalStateMachineDsl.g:1041:1: ( () )
            // InternalStateMachineDsl.g:1042:2: ()
            {
             before(grammarAccess.getStateAccess().getStateAction_0()); 
            // InternalStateMachineDsl.g:1043:2: ()
            // InternalStateMachineDsl.g:1043:3: 
            {
            }

             after(grammarAccess.getStateAccess().getStateAction_0()); 

            }


            }

        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__State__Group__0__Impl"


    // $ANTLR start "rule__State__Group__1"
    // InternalStateMachineDsl.g:1051:1: rule__State__Group__1 : rule__State__Group__1__Impl rule__State__Group__2 ;
    public final void rule__State__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalStateMachineDsl.g:1055:1: ( rule__State__Group__1__Impl rule__State__Group__2 )
            // InternalStateMachineDsl.g:1056:2: rule__State__Group__1__Impl rule__State__Group__2
            {
            pushFollow(FOLLOW_4);
            rule__State__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__State__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__State__Group__1"


    // $ANTLR start "rule__State__Group__1__Impl"
    // InternalStateMachineDsl.g:1063:1: rule__State__Group__1__Impl : ( 'state' ) ;
    public final void rule__State__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalStateMachineDsl.g:1067:1: ( ( 'state' ) )
            // InternalStateMachineDsl.g:1068:1: ( 'state' )
            {
            // InternalStateMachineDsl.g:1068:1: ( 'state' )
            // InternalStateMachineDsl.g:1069:2: 'state'
            {
             before(grammarAccess.getStateAccess().getStateKeyword_1()); 
            match(input,20,FOLLOW_2); 
             after(grammarAccess.getStateAccess().getStateKeyword_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__State__Group__1__Impl"


    // $ANTLR start "rule__State__Group__2"
    // InternalStateMachineDsl.g:1078:1: rule__State__Group__2 : rule__State__Group__2__Impl rule__State__Group__3 ;
    public final void rule__State__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalStateMachineDsl.g:1082:1: ( rule__State__Group__2__Impl rule__State__Group__3 )
            // InternalStateMachineDsl.g:1083:2: rule__State__Group__2__Impl rule__State__Group__3
            {
            pushFollow(FOLLOW_5);
            rule__State__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__State__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__State__Group__2"


    // $ANTLR start "rule__State__Group__2__Impl"
    // InternalStateMachineDsl.g:1090:1: rule__State__Group__2__Impl : ( ( rule__State__NameAssignment_2 ) ) ;
    public final void rule__State__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalStateMachineDsl.g:1094:1: ( ( ( rule__State__NameAssignment_2 ) ) )
            // InternalStateMachineDsl.g:1095:1: ( ( rule__State__NameAssignment_2 ) )
            {
            // InternalStateMachineDsl.g:1095:1: ( ( rule__State__NameAssignment_2 ) )
            // InternalStateMachineDsl.g:1096:2: ( rule__State__NameAssignment_2 )
            {
             before(grammarAccess.getStateAccess().getNameAssignment_2()); 
            // InternalStateMachineDsl.g:1097:2: ( rule__State__NameAssignment_2 )
            // InternalStateMachineDsl.g:1097:3: rule__State__NameAssignment_2
            {
            pushFollow(FOLLOW_2);
            rule__State__NameAssignment_2();

            state._fsp--;


            }

             after(grammarAccess.getStateAccess().getNameAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__State__Group__2__Impl"


    // $ANTLR start "rule__State__Group__3"
    // InternalStateMachineDsl.g:1105:1: rule__State__Group__3 : rule__State__Group__3__Impl rule__State__Group__4 ;
    public final void rule__State__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalStateMachineDsl.g:1109:1: ( rule__State__Group__3__Impl rule__State__Group__4 )
            // InternalStateMachineDsl.g:1110:2: rule__State__Group__3__Impl rule__State__Group__4
            {
            pushFollow(FOLLOW_12);
            rule__State__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__State__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__State__Group__3"


    // $ANTLR start "rule__State__Group__3__Impl"
    // InternalStateMachineDsl.g:1117:1: rule__State__Group__3__Impl : ( '{' ) ;
    public final void rule__State__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalStateMachineDsl.g:1121:1: ( ( '{' ) )
            // InternalStateMachineDsl.g:1122:1: ( '{' )
            {
            // InternalStateMachineDsl.g:1122:1: ( '{' )
            // InternalStateMachineDsl.g:1123:2: '{'
            {
             before(grammarAccess.getStateAccess().getLeftCurlyBracketKeyword_3()); 
            match(input,13,FOLLOW_2); 
             after(grammarAccess.getStateAccess().getLeftCurlyBracketKeyword_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__State__Group__3__Impl"


    // $ANTLR start "rule__State__Group__4"
    // InternalStateMachineDsl.g:1132:1: rule__State__Group__4 : rule__State__Group__4__Impl rule__State__Group__5 ;
    public final void rule__State__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalStateMachineDsl.g:1136:1: ( rule__State__Group__4__Impl rule__State__Group__5 )
            // InternalStateMachineDsl.g:1137:2: rule__State__Group__4__Impl rule__State__Group__5
            {
            pushFollow(FOLLOW_13);
            rule__State__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__State__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__State__Group__4"


    // $ANTLR start "rule__State__Group__4__Impl"
    // InternalStateMachineDsl.g:1144:1: rule__State__Group__4__Impl : ( ( rule__State__Alternatives_4 ) ) ;
    public final void rule__State__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalStateMachineDsl.g:1148:1: ( ( ( rule__State__Alternatives_4 ) ) )
            // InternalStateMachineDsl.g:1149:1: ( ( rule__State__Alternatives_4 ) )
            {
            // InternalStateMachineDsl.g:1149:1: ( ( rule__State__Alternatives_4 ) )
            // InternalStateMachineDsl.g:1150:2: ( rule__State__Alternatives_4 )
            {
             before(grammarAccess.getStateAccess().getAlternatives_4()); 
            // InternalStateMachineDsl.g:1151:2: ( rule__State__Alternatives_4 )
            // InternalStateMachineDsl.g:1151:3: rule__State__Alternatives_4
            {
            pushFollow(FOLLOW_2);
            rule__State__Alternatives_4();

            state._fsp--;


            }

             after(grammarAccess.getStateAccess().getAlternatives_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__State__Group__4__Impl"


    // $ANTLR start "rule__State__Group__5"
    // InternalStateMachineDsl.g:1159:1: rule__State__Group__5 : rule__State__Group__5__Impl ;
    public final void rule__State__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalStateMachineDsl.g:1163:1: ( rule__State__Group__5__Impl )
            // InternalStateMachineDsl.g:1164:2: rule__State__Group__5__Impl
            {
            pushFollow(FOLLOW_2);
            rule__State__Group__5__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__State__Group__5"


    // $ANTLR start "rule__State__Group__5__Impl"
    // InternalStateMachineDsl.g:1170:1: rule__State__Group__5__Impl : ( '}' ) ;
    public final void rule__State__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalStateMachineDsl.g:1174:1: ( ( '}' ) )
            // InternalStateMachineDsl.g:1175:1: ( '}' )
            {
            // InternalStateMachineDsl.g:1175:1: ( '}' )
            // InternalStateMachineDsl.g:1176:2: '}'
            {
             before(grammarAccess.getStateAccess().getRightCurlyBracketKeyword_5()); 
            match(input,14,FOLLOW_2); 
             after(grammarAccess.getStateAccess().getRightCurlyBracketKeyword_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__State__Group__5__Impl"


    // $ANTLR start "rule__Transition__Group__0"
    // InternalStateMachineDsl.g:1186:1: rule__Transition__Group__0 : rule__Transition__Group__0__Impl rule__Transition__Group__1 ;
    public final void rule__Transition__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalStateMachineDsl.g:1190:1: ( rule__Transition__Group__0__Impl rule__Transition__Group__1 )
            // InternalStateMachineDsl.g:1191:2: rule__Transition__Group__0__Impl rule__Transition__Group__1
            {
            pushFollow(FOLLOW_4);
            rule__Transition__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Transition__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Transition__Group__0"


    // $ANTLR start "rule__Transition__Group__0__Impl"
    // InternalStateMachineDsl.g:1198:1: rule__Transition__Group__0__Impl : ( 'transition' ) ;
    public final void rule__Transition__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalStateMachineDsl.g:1202:1: ( ( 'transition' ) )
            // InternalStateMachineDsl.g:1203:1: ( 'transition' )
            {
            // InternalStateMachineDsl.g:1203:1: ( 'transition' )
            // InternalStateMachineDsl.g:1204:2: 'transition'
            {
             before(grammarAccess.getTransitionAccess().getTransitionKeyword_0()); 
            match(input,21,FOLLOW_2); 
             after(grammarAccess.getTransitionAccess().getTransitionKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Transition__Group__0__Impl"


    // $ANTLR start "rule__Transition__Group__1"
    // InternalStateMachineDsl.g:1213:1: rule__Transition__Group__1 : rule__Transition__Group__1__Impl rule__Transition__Group__2 ;
    public final void rule__Transition__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalStateMachineDsl.g:1217:1: ( rule__Transition__Group__1__Impl rule__Transition__Group__2 )
            // InternalStateMachineDsl.g:1218:2: rule__Transition__Group__1__Impl rule__Transition__Group__2
            {
            pushFollow(FOLLOW_5);
            rule__Transition__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Transition__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Transition__Group__1"


    // $ANTLR start "rule__Transition__Group__1__Impl"
    // InternalStateMachineDsl.g:1225:1: rule__Transition__Group__1__Impl : ( ( rule__Transition__NameAssignment_1 ) ) ;
    public final void rule__Transition__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalStateMachineDsl.g:1229:1: ( ( ( rule__Transition__NameAssignment_1 ) ) )
            // InternalStateMachineDsl.g:1230:1: ( ( rule__Transition__NameAssignment_1 ) )
            {
            // InternalStateMachineDsl.g:1230:1: ( ( rule__Transition__NameAssignment_1 ) )
            // InternalStateMachineDsl.g:1231:2: ( rule__Transition__NameAssignment_1 )
            {
             before(grammarAccess.getTransitionAccess().getNameAssignment_1()); 
            // InternalStateMachineDsl.g:1232:2: ( rule__Transition__NameAssignment_1 )
            // InternalStateMachineDsl.g:1232:3: rule__Transition__NameAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__Transition__NameAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getTransitionAccess().getNameAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Transition__Group__1__Impl"


    // $ANTLR start "rule__Transition__Group__2"
    // InternalStateMachineDsl.g:1240:1: rule__Transition__Group__2 : rule__Transition__Group__2__Impl rule__Transition__Group__3 ;
    public final void rule__Transition__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalStateMachineDsl.g:1244:1: ( rule__Transition__Group__2__Impl rule__Transition__Group__3 )
            // InternalStateMachineDsl.g:1245:2: rule__Transition__Group__2__Impl rule__Transition__Group__3
            {
            pushFollow(FOLLOW_14);
            rule__Transition__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Transition__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Transition__Group__2"


    // $ANTLR start "rule__Transition__Group__2__Impl"
    // InternalStateMachineDsl.g:1252:1: rule__Transition__Group__2__Impl : ( '{' ) ;
    public final void rule__Transition__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalStateMachineDsl.g:1256:1: ( ( '{' ) )
            // InternalStateMachineDsl.g:1257:1: ( '{' )
            {
            // InternalStateMachineDsl.g:1257:1: ( '{' )
            // InternalStateMachineDsl.g:1258:2: '{'
            {
             before(grammarAccess.getTransitionAccess().getLeftCurlyBracketKeyword_2()); 
            match(input,13,FOLLOW_2); 
             after(grammarAccess.getTransitionAccess().getLeftCurlyBracketKeyword_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Transition__Group__2__Impl"


    // $ANTLR start "rule__Transition__Group__3"
    // InternalStateMachineDsl.g:1267:1: rule__Transition__Group__3 : rule__Transition__Group__3__Impl rule__Transition__Group__4 ;
    public final void rule__Transition__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalStateMachineDsl.g:1271:1: ( rule__Transition__Group__3__Impl rule__Transition__Group__4 )
            // InternalStateMachineDsl.g:1272:2: rule__Transition__Group__3__Impl rule__Transition__Group__4
            {
            pushFollow(FOLLOW_4);
            rule__Transition__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Transition__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Transition__Group__3"


    // $ANTLR start "rule__Transition__Group__3__Impl"
    // InternalStateMachineDsl.g:1279:1: rule__Transition__Group__3__Impl : ( 'event' ) ;
    public final void rule__Transition__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalStateMachineDsl.g:1283:1: ( ( 'event' ) )
            // InternalStateMachineDsl.g:1284:1: ( 'event' )
            {
            // InternalStateMachineDsl.g:1284:1: ( 'event' )
            // InternalStateMachineDsl.g:1285:2: 'event'
            {
             before(grammarAccess.getTransitionAccess().getEventKeyword_3()); 
            match(input,22,FOLLOW_2); 
             after(grammarAccess.getTransitionAccess().getEventKeyword_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Transition__Group__3__Impl"


    // $ANTLR start "rule__Transition__Group__4"
    // InternalStateMachineDsl.g:1294:1: rule__Transition__Group__4 : rule__Transition__Group__4__Impl rule__Transition__Group__5 ;
    public final void rule__Transition__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalStateMachineDsl.g:1298:1: ( rule__Transition__Group__4__Impl rule__Transition__Group__5 )
            // InternalStateMachineDsl.g:1299:2: rule__Transition__Group__4__Impl rule__Transition__Group__5
            {
            pushFollow(FOLLOW_15);
            rule__Transition__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Transition__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Transition__Group__4"


    // $ANTLR start "rule__Transition__Group__4__Impl"
    // InternalStateMachineDsl.g:1306:1: rule__Transition__Group__4__Impl : ( ( rule__Transition__TypeAssignment_4 ) ) ;
    public final void rule__Transition__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalStateMachineDsl.g:1310:1: ( ( ( rule__Transition__TypeAssignment_4 ) ) )
            // InternalStateMachineDsl.g:1311:1: ( ( rule__Transition__TypeAssignment_4 ) )
            {
            // InternalStateMachineDsl.g:1311:1: ( ( rule__Transition__TypeAssignment_4 ) )
            // InternalStateMachineDsl.g:1312:2: ( rule__Transition__TypeAssignment_4 )
            {
             before(grammarAccess.getTransitionAccess().getTypeAssignment_4()); 
            // InternalStateMachineDsl.g:1313:2: ( rule__Transition__TypeAssignment_4 )
            // InternalStateMachineDsl.g:1313:3: rule__Transition__TypeAssignment_4
            {
            pushFollow(FOLLOW_2);
            rule__Transition__TypeAssignment_4();

            state._fsp--;


            }

             after(grammarAccess.getTransitionAccess().getTypeAssignment_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Transition__Group__4__Impl"


    // $ANTLR start "rule__Transition__Group__5"
    // InternalStateMachineDsl.g:1321:1: rule__Transition__Group__5 : rule__Transition__Group__5__Impl rule__Transition__Group__6 ;
    public final void rule__Transition__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalStateMachineDsl.g:1325:1: ( rule__Transition__Group__5__Impl rule__Transition__Group__6 )
            // InternalStateMachineDsl.g:1326:2: rule__Transition__Group__5__Impl rule__Transition__Group__6
            {
            pushFollow(FOLLOW_4);
            rule__Transition__Group__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Transition__Group__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Transition__Group__5"


    // $ANTLR start "rule__Transition__Group__5__Impl"
    // InternalStateMachineDsl.g:1333:1: rule__Transition__Group__5__Impl : ( 'from' ) ;
    public final void rule__Transition__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalStateMachineDsl.g:1337:1: ( ( 'from' ) )
            // InternalStateMachineDsl.g:1338:1: ( 'from' )
            {
            // InternalStateMachineDsl.g:1338:1: ( 'from' )
            // InternalStateMachineDsl.g:1339:2: 'from'
            {
             before(grammarAccess.getTransitionAccess().getFromKeyword_5()); 
            match(input,23,FOLLOW_2); 
             after(grammarAccess.getTransitionAccess().getFromKeyword_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Transition__Group__5__Impl"


    // $ANTLR start "rule__Transition__Group__6"
    // InternalStateMachineDsl.g:1348:1: rule__Transition__Group__6 : rule__Transition__Group__6__Impl rule__Transition__Group__7 ;
    public final void rule__Transition__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalStateMachineDsl.g:1352:1: ( rule__Transition__Group__6__Impl rule__Transition__Group__7 )
            // InternalStateMachineDsl.g:1353:2: rule__Transition__Group__6__Impl rule__Transition__Group__7
            {
            pushFollow(FOLLOW_16);
            rule__Transition__Group__6__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Transition__Group__7();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Transition__Group__6"


    // $ANTLR start "rule__Transition__Group__6__Impl"
    // InternalStateMachineDsl.g:1360:1: rule__Transition__Group__6__Impl : ( ( rule__Transition__SourceAssignment_6 ) ) ;
    public final void rule__Transition__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalStateMachineDsl.g:1364:1: ( ( ( rule__Transition__SourceAssignment_6 ) ) )
            // InternalStateMachineDsl.g:1365:1: ( ( rule__Transition__SourceAssignment_6 ) )
            {
            // InternalStateMachineDsl.g:1365:1: ( ( rule__Transition__SourceAssignment_6 ) )
            // InternalStateMachineDsl.g:1366:2: ( rule__Transition__SourceAssignment_6 )
            {
             before(grammarAccess.getTransitionAccess().getSourceAssignment_6()); 
            // InternalStateMachineDsl.g:1367:2: ( rule__Transition__SourceAssignment_6 )
            // InternalStateMachineDsl.g:1367:3: rule__Transition__SourceAssignment_6
            {
            pushFollow(FOLLOW_2);
            rule__Transition__SourceAssignment_6();

            state._fsp--;


            }

             after(grammarAccess.getTransitionAccess().getSourceAssignment_6()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Transition__Group__6__Impl"


    // $ANTLR start "rule__Transition__Group__7"
    // InternalStateMachineDsl.g:1375:1: rule__Transition__Group__7 : rule__Transition__Group__7__Impl rule__Transition__Group__8 ;
    public final void rule__Transition__Group__7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalStateMachineDsl.g:1379:1: ( rule__Transition__Group__7__Impl rule__Transition__Group__8 )
            // InternalStateMachineDsl.g:1380:2: rule__Transition__Group__7__Impl rule__Transition__Group__8
            {
            pushFollow(FOLLOW_4);
            rule__Transition__Group__7__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Transition__Group__8();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Transition__Group__7"


    // $ANTLR start "rule__Transition__Group__7__Impl"
    // InternalStateMachineDsl.g:1387:1: rule__Transition__Group__7__Impl : ( 'to' ) ;
    public final void rule__Transition__Group__7__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalStateMachineDsl.g:1391:1: ( ( 'to' ) )
            // InternalStateMachineDsl.g:1392:1: ( 'to' )
            {
            // InternalStateMachineDsl.g:1392:1: ( 'to' )
            // InternalStateMachineDsl.g:1393:2: 'to'
            {
             before(grammarAccess.getTransitionAccess().getToKeyword_7()); 
            match(input,24,FOLLOW_2); 
             after(grammarAccess.getTransitionAccess().getToKeyword_7()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Transition__Group__7__Impl"


    // $ANTLR start "rule__Transition__Group__8"
    // InternalStateMachineDsl.g:1402:1: rule__Transition__Group__8 : rule__Transition__Group__8__Impl rule__Transition__Group__9 ;
    public final void rule__Transition__Group__8() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalStateMachineDsl.g:1406:1: ( rule__Transition__Group__8__Impl rule__Transition__Group__9 )
            // InternalStateMachineDsl.g:1407:2: rule__Transition__Group__8__Impl rule__Transition__Group__9
            {
            pushFollow(FOLLOW_13);
            rule__Transition__Group__8__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Transition__Group__9();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Transition__Group__8"


    // $ANTLR start "rule__Transition__Group__8__Impl"
    // InternalStateMachineDsl.g:1414:1: rule__Transition__Group__8__Impl : ( ( rule__Transition__TargetAssignment_8 ) ) ;
    public final void rule__Transition__Group__8__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalStateMachineDsl.g:1418:1: ( ( ( rule__Transition__TargetAssignment_8 ) ) )
            // InternalStateMachineDsl.g:1419:1: ( ( rule__Transition__TargetAssignment_8 ) )
            {
            // InternalStateMachineDsl.g:1419:1: ( ( rule__Transition__TargetAssignment_8 ) )
            // InternalStateMachineDsl.g:1420:2: ( rule__Transition__TargetAssignment_8 )
            {
             before(grammarAccess.getTransitionAccess().getTargetAssignment_8()); 
            // InternalStateMachineDsl.g:1421:2: ( rule__Transition__TargetAssignment_8 )
            // InternalStateMachineDsl.g:1421:3: rule__Transition__TargetAssignment_8
            {
            pushFollow(FOLLOW_2);
            rule__Transition__TargetAssignment_8();

            state._fsp--;


            }

             after(grammarAccess.getTransitionAccess().getTargetAssignment_8()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Transition__Group__8__Impl"


    // $ANTLR start "rule__Transition__Group__9"
    // InternalStateMachineDsl.g:1429:1: rule__Transition__Group__9 : rule__Transition__Group__9__Impl ;
    public final void rule__Transition__Group__9() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalStateMachineDsl.g:1433:1: ( rule__Transition__Group__9__Impl )
            // InternalStateMachineDsl.g:1434:2: rule__Transition__Group__9__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Transition__Group__9__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Transition__Group__9"


    // $ANTLR start "rule__Transition__Group__9__Impl"
    // InternalStateMachineDsl.g:1440:1: rule__Transition__Group__9__Impl : ( '}' ) ;
    public final void rule__Transition__Group__9__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalStateMachineDsl.g:1444:1: ( ( '}' ) )
            // InternalStateMachineDsl.g:1445:1: ( '}' )
            {
            // InternalStateMachineDsl.g:1445:1: ( '}' )
            // InternalStateMachineDsl.g:1446:2: '}'
            {
             before(grammarAccess.getTransitionAccess().getRightCurlyBracketKeyword_9()); 
            match(input,14,FOLLOW_2); 
             after(grammarAccess.getTransitionAccess().getRightCurlyBracketKeyword_9()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Transition__Group__9__Impl"


    // $ANTLR start "rule__StateMachine__ElementsAssignment"
    // InternalStateMachineDsl.g:1456:1: rule__StateMachine__ElementsAssignment : ( ruleAbstractElement ) ;
    public final void rule__StateMachine__ElementsAssignment() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalStateMachineDsl.g:1460:1: ( ( ruleAbstractElement ) )
            // InternalStateMachineDsl.g:1461:2: ( ruleAbstractElement )
            {
            // InternalStateMachineDsl.g:1461:2: ( ruleAbstractElement )
            // InternalStateMachineDsl.g:1462:3: ruleAbstractElement
            {
             before(grammarAccess.getStateMachineAccess().getElementsAbstractElementParserRuleCall_0()); 
            pushFollow(FOLLOW_2);
            ruleAbstractElement();

            state._fsp--;

             after(grammarAccess.getStateMachineAccess().getElementsAbstractElementParserRuleCall_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachine__ElementsAssignment"


    // $ANTLR start "rule__Input__ValueAssignment_1"
    // InternalStateMachineDsl.g:1471:1: rule__Input__ValueAssignment_1 : ( RULE_ID ) ;
    public final void rule__Input__ValueAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalStateMachineDsl.g:1475:1: ( ( RULE_ID ) )
            // InternalStateMachineDsl.g:1476:2: ( RULE_ID )
            {
            // InternalStateMachineDsl.g:1476:2: ( RULE_ID )
            // InternalStateMachineDsl.g:1477:3: RULE_ID
            {
             before(grammarAccess.getInputAccess().getValueIDTerminalRuleCall_1_0()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getInputAccess().getValueIDTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Input__ValueAssignment_1"


    // $ANTLR start "rule__StateMachineDeclaration__NameAssignment_1"
    // InternalStateMachineDsl.g:1486:1: rule__StateMachineDeclaration__NameAssignment_1 : ( ruleQualifiedName ) ;
    public final void rule__StateMachineDeclaration__NameAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalStateMachineDsl.g:1490:1: ( ( ruleQualifiedName ) )
            // InternalStateMachineDsl.g:1491:2: ( ruleQualifiedName )
            {
            // InternalStateMachineDsl.g:1491:2: ( ruleQualifiedName )
            // InternalStateMachineDsl.g:1492:3: ruleQualifiedName
            {
             before(grammarAccess.getStateMachineDeclarationAccess().getNameQualifiedNameParserRuleCall_1_0()); 
            pushFollow(FOLLOW_2);
            ruleQualifiedName();

            state._fsp--;

             after(grammarAccess.getStateMachineDeclarationAccess().getNameQualifiedNameParserRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachineDeclaration__NameAssignment_1"


    // $ANTLR start "rule__StateMachineDeclaration__ElementsAssignment_3"
    // InternalStateMachineDsl.g:1501:1: rule__StateMachineDeclaration__ElementsAssignment_3 : ( ruleAbstractElement ) ;
    public final void rule__StateMachineDeclaration__ElementsAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalStateMachineDsl.g:1505:1: ( ( ruleAbstractElement ) )
            // InternalStateMachineDsl.g:1506:2: ( ruleAbstractElement )
            {
            // InternalStateMachineDsl.g:1506:2: ( ruleAbstractElement )
            // InternalStateMachineDsl.g:1507:3: ruleAbstractElement
            {
             before(grammarAccess.getStateMachineDeclarationAccess().getElementsAbstractElementParserRuleCall_3_0()); 
            pushFollow(FOLLOW_2);
            ruleAbstractElement();

            state._fsp--;

             after(grammarAccess.getStateMachineDeclarationAccess().getElementsAbstractElementParserRuleCall_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachineDeclaration__ElementsAssignment_3"


    // $ANTLR start "rule__Import__ImportedNamespaceAssignment_1"
    // InternalStateMachineDsl.g:1516:1: rule__Import__ImportedNamespaceAssignment_1 : ( ruleQualifiedNameWithWildcard ) ;
    public final void rule__Import__ImportedNamespaceAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalStateMachineDsl.g:1520:1: ( ( ruleQualifiedNameWithWildcard ) )
            // InternalStateMachineDsl.g:1521:2: ( ruleQualifiedNameWithWildcard )
            {
            // InternalStateMachineDsl.g:1521:2: ( ruleQualifiedNameWithWildcard )
            // InternalStateMachineDsl.g:1522:3: ruleQualifiedNameWithWildcard
            {
             before(grammarAccess.getImportAccess().getImportedNamespaceQualifiedNameWithWildcardParserRuleCall_1_0()); 
            pushFollow(FOLLOW_2);
            ruleQualifiedNameWithWildcard();

            state._fsp--;

             after(grammarAccess.getImportAccess().getImportedNamespaceQualifiedNameWithWildcardParserRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Import__ImportedNamespaceAssignment_1"


    // $ANTLR start "rule__SingleLabel__LabelAssignment_1"
    // InternalStateMachineDsl.g:1531:1: rule__SingleLabel__LabelAssignment_1 : ( ruleLabelName ) ;
    public final void rule__SingleLabel__LabelAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalStateMachineDsl.g:1535:1: ( ( ruleLabelName ) )
            // InternalStateMachineDsl.g:1536:2: ( ruleLabelName )
            {
            // InternalStateMachineDsl.g:1536:2: ( ruleLabelName )
            // InternalStateMachineDsl.g:1537:3: ruleLabelName
            {
             before(grammarAccess.getSingleLabelAccess().getLabelLabelNameParserRuleCall_1_0()); 
            pushFollow(FOLLOW_2);
            ruleLabelName();

            state._fsp--;

             after(grammarAccess.getSingleLabelAccess().getLabelLabelNameParserRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SingleLabel__LabelAssignment_1"


    // $ANTLR start "rule__ListOfLabels__LabelsAssignment_1"
    // InternalStateMachineDsl.g:1546:1: rule__ListOfLabels__LabelsAssignment_1 : ( ruleLabelName ) ;
    public final void rule__ListOfLabels__LabelsAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalStateMachineDsl.g:1550:1: ( ( ruleLabelName ) )
            // InternalStateMachineDsl.g:1551:2: ( ruleLabelName )
            {
            // InternalStateMachineDsl.g:1551:2: ( ruleLabelName )
            // InternalStateMachineDsl.g:1552:3: ruleLabelName
            {
             before(grammarAccess.getListOfLabelsAccess().getLabelsLabelNameParserRuleCall_1_0()); 
            pushFollow(FOLLOW_2);
            ruleLabelName();

            state._fsp--;

             after(grammarAccess.getListOfLabelsAccess().getLabelsLabelNameParserRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ListOfLabels__LabelsAssignment_1"


    // $ANTLR start "rule__LabelName__NameAssignment"
    // InternalStateMachineDsl.g:1561:1: rule__LabelName__NameAssignment : ( RULE_ID ) ;
    public final void rule__LabelName__NameAssignment() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalStateMachineDsl.g:1565:1: ( ( RULE_ID ) )
            // InternalStateMachineDsl.g:1566:2: ( RULE_ID )
            {
            // InternalStateMachineDsl.g:1566:2: ( RULE_ID )
            // InternalStateMachineDsl.g:1567:3: RULE_ID
            {
             before(grammarAccess.getLabelNameAccess().getNameIDTerminalRuleCall_0()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getLabelNameAccess().getNameIDTerminalRuleCall_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__LabelName__NameAssignment"


    // $ANTLR start "rule__State__NameAssignment_2"
    // InternalStateMachineDsl.g:1576:1: rule__State__NameAssignment_2 : ( RULE_ID ) ;
    public final void rule__State__NameAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalStateMachineDsl.g:1580:1: ( ( RULE_ID ) )
            // InternalStateMachineDsl.g:1581:2: ( RULE_ID )
            {
            // InternalStateMachineDsl.g:1581:2: ( RULE_ID )
            // InternalStateMachineDsl.g:1582:3: RULE_ID
            {
             before(grammarAccess.getStateAccess().getNameIDTerminalRuleCall_2_0()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getStateAccess().getNameIDTerminalRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__State__NameAssignment_2"


    // $ANTLR start "rule__State__IsFinalAssignment_4_0"
    // InternalStateMachineDsl.g:1591:1: rule__State__IsFinalAssignment_4_0 : ( ( 'final' ) ) ;
    public final void rule__State__IsFinalAssignment_4_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalStateMachineDsl.g:1595:1: ( ( ( 'final' ) ) )
            // InternalStateMachineDsl.g:1596:2: ( ( 'final' ) )
            {
            // InternalStateMachineDsl.g:1596:2: ( ( 'final' ) )
            // InternalStateMachineDsl.g:1597:3: ( 'final' )
            {
             before(grammarAccess.getStateAccess().getIsFinalFinalKeyword_4_0_0()); 
            // InternalStateMachineDsl.g:1598:3: ( 'final' )
            // InternalStateMachineDsl.g:1599:4: 'final'
            {
             before(grammarAccess.getStateAccess().getIsFinalFinalKeyword_4_0_0()); 
            match(input,25,FOLLOW_2); 
             after(grammarAccess.getStateAccess().getIsFinalFinalKeyword_4_0_0()); 

            }

             after(grammarAccess.getStateAccess().getIsFinalFinalKeyword_4_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__State__IsFinalAssignment_4_0"


    // $ANTLR start "rule__State__IsInitialAssignment_4_1"
    // InternalStateMachineDsl.g:1610:1: rule__State__IsInitialAssignment_4_1 : ( ( 'initial' ) ) ;
    public final void rule__State__IsInitialAssignment_4_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalStateMachineDsl.g:1614:1: ( ( ( 'initial' ) ) )
            // InternalStateMachineDsl.g:1615:2: ( ( 'initial' ) )
            {
            // InternalStateMachineDsl.g:1615:2: ( ( 'initial' ) )
            // InternalStateMachineDsl.g:1616:3: ( 'initial' )
            {
             before(grammarAccess.getStateAccess().getIsInitialInitialKeyword_4_1_0()); 
            // InternalStateMachineDsl.g:1617:3: ( 'initial' )
            // InternalStateMachineDsl.g:1618:4: 'initial'
            {
             before(grammarAccess.getStateAccess().getIsInitialInitialKeyword_4_1_0()); 
            match(input,26,FOLLOW_2); 
             after(grammarAccess.getStateAccess().getIsInitialInitialKeyword_4_1_0()); 

            }

             after(grammarAccess.getStateAccess().getIsInitialInitialKeyword_4_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__State__IsInitialAssignment_4_1"


    // $ANTLR start "rule__Transition__NameAssignment_1"
    // InternalStateMachineDsl.g:1629:1: rule__Transition__NameAssignment_1 : ( RULE_ID ) ;
    public final void rule__Transition__NameAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalStateMachineDsl.g:1633:1: ( ( RULE_ID ) )
            // InternalStateMachineDsl.g:1634:2: ( RULE_ID )
            {
            // InternalStateMachineDsl.g:1634:2: ( RULE_ID )
            // InternalStateMachineDsl.g:1635:3: RULE_ID
            {
             before(grammarAccess.getTransitionAccess().getNameIDTerminalRuleCall_1_0()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getTransitionAccess().getNameIDTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Transition__NameAssignment_1"


    // $ANTLR start "rule__Transition__TypeAssignment_4"
    // InternalStateMachineDsl.g:1644:1: rule__Transition__TypeAssignment_4 : ( ( RULE_ID ) ) ;
    public final void rule__Transition__TypeAssignment_4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalStateMachineDsl.g:1648:1: ( ( ( RULE_ID ) ) )
            // InternalStateMachineDsl.g:1649:2: ( ( RULE_ID ) )
            {
            // InternalStateMachineDsl.g:1649:2: ( ( RULE_ID ) )
            // InternalStateMachineDsl.g:1650:3: ( RULE_ID )
            {
             before(grammarAccess.getTransitionAccess().getTypeLabelNameCrossReference_4_0()); 
            // InternalStateMachineDsl.g:1651:3: ( RULE_ID )
            // InternalStateMachineDsl.g:1652:4: RULE_ID
            {
             before(grammarAccess.getTransitionAccess().getTypeLabelNameIDTerminalRuleCall_4_0_1()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getTransitionAccess().getTypeLabelNameIDTerminalRuleCall_4_0_1()); 

            }

             after(grammarAccess.getTransitionAccess().getTypeLabelNameCrossReference_4_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Transition__TypeAssignment_4"


    // $ANTLR start "rule__Transition__SourceAssignment_6"
    // InternalStateMachineDsl.g:1663:1: rule__Transition__SourceAssignment_6 : ( ( RULE_ID ) ) ;
    public final void rule__Transition__SourceAssignment_6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalStateMachineDsl.g:1667:1: ( ( ( RULE_ID ) ) )
            // InternalStateMachineDsl.g:1668:2: ( ( RULE_ID ) )
            {
            // InternalStateMachineDsl.g:1668:2: ( ( RULE_ID ) )
            // InternalStateMachineDsl.g:1669:3: ( RULE_ID )
            {
             before(grammarAccess.getTransitionAccess().getSourceStateCrossReference_6_0()); 
            // InternalStateMachineDsl.g:1670:3: ( RULE_ID )
            // InternalStateMachineDsl.g:1671:4: RULE_ID
            {
             before(grammarAccess.getTransitionAccess().getSourceStateIDTerminalRuleCall_6_0_1()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getTransitionAccess().getSourceStateIDTerminalRuleCall_6_0_1()); 

            }

             after(grammarAccess.getTransitionAccess().getSourceStateCrossReference_6_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Transition__SourceAssignment_6"


    // $ANTLR start "rule__Transition__TargetAssignment_8"
    // InternalStateMachineDsl.g:1682:1: rule__Transition__TargetAssignment_8 : ( ( RULE_ID ) ) ;
    public final void rule__Transition__TargetAssignment_8() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalStateMachineDsl.g:1686:1: ( ( ( RULE_ID ) ) )
            // InternalStateMachineDsl.g:1687:2: ( ( RULE_ID ) )
            {
            // InternalStateMachineDsl.g:1687:2: ( ( RULE_ID ) )
            // InternalStateMachineDsl.g:1688:3: ( RULE_ID )
            {
             before(grammarAccess.getTransitionAccess().getTargetStateCrossReference_8_0()); 
            // InternalStateMachineDsl.g:1689:3: ( RULE_ID )
            // InternalStateMachineDsl.g:1690:4: RULE_ID
            {
             before(grammarAccess.getTransitionAccess().getTargetStateIDTerminalRuleCall_8_0_1()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getTransitionAccess().getTargetStateIDTerminalRuleCall_8_0_1()); 

            }

             after(grammarAccess.getTransitionAccess().getTargetStateCrossReference_8_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Transition__TargetAssignment_8"

    // Delegated rules


 

    public static final BitSet FOLLOW_1 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_2 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_3 = new BitSet(new long[]{0x00000000003D1802L});
    public static final BitSet FOLLOW_4 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_5 = new BitSet(new long[]{0x0000000000002000L});
    public static final BitSet FOLLOW_6 = new BitSet(new long[]{0x00000000003D5800L});
    public static final BitSet FOLLOW_7 = new BitSet(new long[]{0x0000000000008000L});
    public static final BitSet FOLLOW_8 = new BitSet(new long[]{0x0000000000008002L});
    public static final BitSet FOLLOW_9 = new BitSet(new long[]{0x0000000000020000L});
    public static final BitSet FOLLOW_10 = new BitSet(new long[]{0x0000000000000012L});
    public static final BitSet FOLLOW_11 = new BitSet(new long[]{0x0000000000100000L});
    public static final BitSet FOLLOW_12 = new BitSet(new long[]{0x0000000006000000L});
    public static final BitSet FOLLOW_13 = new BitSet(new long[]{0x0000000000004000L});
    public static final BitSet FOLLOW_14 = new BitSet(new long[]{0x0000000000400000L});
    public static final BitSet FOLLOW_15 = new BitSet(new long[]{0x0000000000800000L});
    public static final BitSet FOLLOW_16 = new BitSet(new long[]{0x0000000001000000L});

}